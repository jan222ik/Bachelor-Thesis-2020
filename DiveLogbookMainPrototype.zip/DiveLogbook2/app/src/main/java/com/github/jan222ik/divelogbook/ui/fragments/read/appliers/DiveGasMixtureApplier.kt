package com.github.jan222ik.divelogbook.ui.fragments.read.appliers

import android.view.View
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.database.entities.DiveGasMixtureEntity
import kotlinx.android.synthetic.main.detail_dive_gas_mixture.view.*

object DiveGasMixtureApplier : DetailApplier<DiveGasMixtureEntity?> {
    override fun apply(view: View, data: DiveGasMixtureEntity?, hideEmpty: Boolean): Boolean {
        with(view) {

            val missing = lazy { resources.getString(R.string.missingData) }
            val barStart = data?.barStart
            val barEnd = data?.barEnd
            val tankSize = data?.tankSize
            val mixtureType = data?.mixtureType
            val o2 = data?.o2
            var vis = barStart.visibilityFor(listOf(barStartLabel, gasMixtureBarStart), hideEmpty)
            vis = vis and barEnd.visibilityFor(listOf(gasMixtureBarEndLabel, gasMixtureBarEnd), hideEmpty)
            vis = vis and tankSize.visibilityFor(listOf(gasMixtureTankSizeLabel, gasMixtureTankSize), hideEmpty)
            vis = vis and mixtureType.visibilityFor(listOf(gasMixtureTypeLabel, gasMixtureType), hideEmpty)
            vis = vis and o2.visibilityFor(listOf(gasMixtureOxygenPercentLabel, gasMixtureOxygenPercent), hideEmpty)
            gasMixtureBarStart.text = barStart?.toString() ?: missing.value
            gasMixtureBarEnd.text = barEnd?.toString() ?: missing.value
            gasMixtureTankSize.text = tankSize?.toString() ?: missing.value
            gasMixtureType.text = mixtureType?.toString() ?: missing.value
            gasMixtureOxygenPercent.text = o2?.toString() ?: missing.value
            return if (hideEmpty && data == null) true else vis

        }
    }
}