package com.github.jan222ik.divelogbook.ui.fragments.read.appliers

import android.view.View

interface DetailApplier<T> {
    fun apply(view: View, data: T, hideEmpty: Boolean = false) : Boolean

    fun Any?.visibilityFor(views: List<View>, hideEmpty: Boolean): Boolean {
        val vis = if (this@visibilityFor == null && hideEmpty) View.GONE else View.VISIBLE
        views.forEach { it.visibility = vis }
        return vis == View.GONE
    }
}
