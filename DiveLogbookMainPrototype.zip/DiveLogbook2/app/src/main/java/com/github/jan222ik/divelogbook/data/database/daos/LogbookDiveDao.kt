package com.github.jan222ik.divelogbook.data.database.daos

import androidx.paging.DataSource
import androidx.room.*
import androidx.sqlite.db.SimpleSQLiteQuery
import androidx.sqlite.db.SupportSQLiteQuery
import com.github.jan222ik.divelogbook.data.Edit
import com.github.jan222ik.divelogbook.data.database.entities.LogbookDiveEntity
import com.github.jan222ik.divelogbook.data.database.pojos.LogbookDive
import com.github.jan222ik.divelogbook.ui.viewmodel.Filter

@Dao
abstract class LogbookDiveDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun insert(logbookDiveEntity: LogbookDiveEntity): Long

    @Update
    abstract suspend fun update(logbookDiveEntity: LogbookDiveEntity)

    @Query(value = "DELETE FROM logbookDive")
    abstract suspend fun deleteAll()

    @Query(value = "SELECT * FROM logbookDive ORDER BY diveNumber ASC LIMIT 200")
    abstract suspend fun getAll(): List<LogbookDive>

    @Query(value = "Select * From logbookDive ORDER BY diveNumber")
    abstract fun getAllPagedBase(): DataSource.Factory<Int, LogbookDive>

    @RawQuery(observedEntities = [LogbookDive::class])
    //@Query("Select logD.* From logbookDive as logD INNER JOIN dive as d ON logD.diveId == d.diveId WHERE EXISTS(SELECT * FROM DiveLocationEntity as w INNER JOIN AddressEntity as locAdd On locAdd.addressId = w.addressEntityId WHERE w.locationId = d.locationFK AND locAdd.country LIKE ?) OR diveNumber BETWEEN ? AND ? ORDER BY logD.diveNumber")
    internal abstract fun getPagedByFilterQuery(rawQuery: SupportSQLiteQuery): DataSource.Factory<Int, LogbookDive>


    fun getAllPaged(filter: Filter? = null): DataSource.Factory<Int, LogbookDive> {
        if (filter == null) {
            return getAllPagedBase()
        } else {
            var isFirstCall = true
            val logicOperator: () -> String = { if (isFirstCall) {isFirstCall = false; "OR"} else if (filter.isAndMode) "AND" else "OR" }
            val values = mutableListOf<Any>()


            //Check DiveNumber
            val hasStartVal = filter.numberStart != null
            val hasEndVal = filter.numberEnd != null
            val areValueEqual = filter.numberStart == filter.numberEnd

            val numberSubquery = "${logicOperator()} diveNumber " + when {
                hasStartVal && hasEndVal && areValueEqual -> {
                    values.add(filter.numberStart!!)
                    "= ?"
                }
                hasStartVal && hasEndVal -> {
                    values.add(filter.numberStart!!)
                    values.add(filter.numberEnd!!)
                    "BETWEEN ? AND ?"
                }
                hasStartVal -> {
                    values.add(filter.numberStart!!)
                    ">= ?"
                }
                hasEndVal -> {
                    values.add(filter.numberEnd!!)
                    "<= ?"
                }
                else -> ""
            }

            //Check Location
            val locationSubQuery = if (filter.country != null) {
                values.add("%${filter.country!!}%")
                """
                    ${logicOperator()} EXISTS(
                        SELECT * 
                        FROM DiveLocationEntity as w INNER JOIN AddressEntity as locAdd On locAdd.addressId = w.addressEntityId 
                        WHERE w.locationId = d.locationFK AND locAdd.country LIKE ?
                    )
                """.trimIndent()
            } else { "" }


            val query =
                """ Select logD.* 
                From logbookDive as logD INNER JOIN dive as d ON logD.diveId == d.diveId 
                WHERE 1 == 0 $numberSubquery $locationSubQuery ORDER BY logD.diveNumber
            """.trimMargin()

            println("query = ${query}")
            return getPagedByFilterQuery(

                SimpleSQLiteQuery(query, values.toTypedArray())
            )
        }
    }

    @Transaction
    @Query(value = "SELECT * FROM logbookDive WHERE logbookDiveId = :logbookDiveId")
    abstract fun getById(logbookDiveId: Long): LogbookDive

    @Query("SELECT COALESCE(MAX(diveNumber), 0) FROM logbookDive")
    abstract fun getLatestNumber(): Int

}