package com.github.jan222ik.divelogbook.ui.fragments.edit

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import kotlinx.android.synthetic.main.fragment_edit_confirmation.view.*

class EditConfirmationFragment : Fragment() {


    lateinit var navController: NavController

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_edit_confirmation, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        view.acceptBtn.setOnClickListener {
            navController.popBackStack(R.id.editMainFragment, true)
            activity!!.onBackPressed()
        }
    }

}