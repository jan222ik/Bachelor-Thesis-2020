package com.github.jan222ik.divelogbook.data.database.pojos

import androidx.room.Embedded
import androidx.room.Ignore
import com.github.jan222ik.divelogbook.data.database.entities.LogbookDiveEntity

data class LogbookDive(
    @Embedded
    val logbookDiveEntity: LogbookDiveEntity
) {
    @Ignore
    var diveData: SingleDiveData? = null
}