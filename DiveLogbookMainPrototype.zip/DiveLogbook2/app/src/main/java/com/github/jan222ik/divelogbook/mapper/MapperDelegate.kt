package com.github.jan222ik.divelogbook.mapper

import android.util.Log

typealias Change<T> = (oldValue: T, newValue: T, originObject: Any?) -> Unit
typealias IntegrityCheck<T> = (currentValue: T, newValue: T) -> Boolean

class MapperDelegate<T>(
    private var value: T,
    private val name: String? = null,
    private val check: IntegrityCheck<T> = { _, _ -> true }
) {
    private val dependants = mutableListOf<Change<T>>()

    fun getValue(): T = this.value

    @Throws(MappingException::class)
    fun setValue(value: T, originObj: Any? = null) {
        val currentValue = this.value
        if (!check(currentValue, value)) {
            throw MappingException("Check for $name did not hold.")
        } else {
            this.value = value
            updateDependants(currentValue, originObj)
        }
    }

    private fun updateDependants(oldValue: T, originObj: Any?) {
        Log.d("TAG", "updateDependants: " + dependants.size)
        dependants.forEach { it(oldValue, this.value, originObj) }
    }

    fun addDependant(change: Change<T>): Boolean = addDependant(false, change)

    fun addDependant(updateAfterAdd: Boolean = false, change: Change<T>): Boolean {
        val success = dependants.add(change)
        if (success && updateAfterAdd) {
            change(value, value, null)
        }
        return success
    }



}

class MappingException(message: String? = null) : Exception(message)