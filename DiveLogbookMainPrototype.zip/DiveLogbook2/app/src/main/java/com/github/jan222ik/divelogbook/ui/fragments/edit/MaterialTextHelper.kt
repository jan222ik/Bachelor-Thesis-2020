package com.github.jan222ik.divelogbook.ui.fragments.edit

import android.content.res.Resources
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.Edit
import com.google.android.material.textfield.TextInputLayout

object MaterialTextHelper {
    fun iconOf(edit: Edit<*>) : Int? {
        return when (edit) {
            is Edit.Unclaimed, is Edit.ByUser -> null
            is Edit.PredictionBy.Camera -> R.drawable.ic_action_camera
            is Edit.PredictionBy.History -> R.drawable.ic_action_robot
            is Edit.PredictionBy.Calculated -> R.drawable.ic_action_robot
            is Edit.PredictionBy.Sensor -> R.drawable.ic_action_robot
        }
    }

    fun apply(
        iconFor: Edit<*>,
        suffix: String?,
        layout: TextInputLayout,
        resources: Resources
    ) {
        val iconOf = iconOf(iconFor)
        layout.suffixText = suffix
        if (iconOf != null) {
            layout.endIconMode = TextInputLayout.END_ICON_CUSTOM
            layout.endIconDrawable = resources.getDrawable(iconOf)
        } else {
            layout.endIconMode = TextInputLayout.END_ICON_NONE
        }
    }
}


fun TextInputLayout.updateIcon(
    iconFor: Edit<*>,
    resources: Resources
) {
    val iconOf = MaterialTextHelper.iconOf(iconFor)
    if (iconOf != null) {
        this.endIconMode = TextInputLayout.END_ICON_CUSTOM
        this.endIconDrawable = resources.getDrawable(iconOf)
    } else {
        this.endIconMode = TextInputLayout.END_ICON_NONE
    }
}