package com.github.jan222ik.divelogbook.data.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDateTime

@Entity
data class DiveTemporalEntity(
    val durationSec: Int,
    val dateTimeIn: LocalDateTime?,
    val dateTimeOut: LocalDateTime?
) {
    @PrimaryKey
    var diveTemporalId: Long? = null
}