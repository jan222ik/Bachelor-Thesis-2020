package com.github.jan222ik.divelogbook.ui.fragments.read.divelist

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.paging.PagedListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.database.pojos.LogbookDive
import com.github.jan222ik.divelogbook.data.m
import com.github.jan222ik.divelogbook.data.minWithSec
import kotlinx.android.synthetic.main.divelist_item.view.*
import java.time.format.DateTimeFormatter
import java.util.function.Consumer

class PagedAdapter(private val onItemClick: DiveListItemListeners) :
    PagedListAdapter<LogbookDive, PagedAdapter.ViewHolder>(
        DiffUtilCallBack()
    ) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.divelist_item, parent, false)
        return ViewHolder(
            view,
            onItemClick
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        getItem(position)?.let { holder.bindPost(it) }
    }


    class ViewHolder(itemView: View, private val onItemClick: DiveListItemListeners) :
        RecyclerView.ViewHolder(itemView),
        View.OnClickListener {

        private lateinit var logbookDive: LogbookDive
        private var expandedChangeListener: Consumer<Boolean>? = null

        fun bindPost(it: LogbookDive) {
            itemView.show_more.rotation = 180F
            itemView.extraInfo.visibility = View.GONE
            logbookDive = it
            val dive = logbookDive.diveData
            with(itemView) {
                divenumber.text = logbookDive.logbookDiveEntity.diveNumber.toString()
                dateTV.text =
                    dive?.temporal?.dateTimeIn?.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
                spotname.text = dive?.location?.spot?.spotName ?: "No data"
                maxDepthTV.text = dive?.depth?.maxMetric.m()
                durationTV.text = dive?.temporal?.durationSec.minWithSec()
            }
        }

        init {
            with(itemView) {
                itemView.setOnClickListener(this@ViewHolder)
                show_more.rotation = 180F
                show_more.setOnClickListener { v: View? ->
                    if (v != null) {
                        if (v.rotation == 180F) {
                            extraInfo.visibility = View.VISIBLE
                            expandedChangeListener?.accept(true)
                            v.rotation = 0F
                        } else {
                            extraInfo.visibility = View.GONE
                            expandedChangeListener?.accept(false)
                            v.rotation = 180F
                        }
                    }
                }
            }
        }

        override fun onClick(v: View?) {
            onItemClick.onDiveClickListener(logbookDive)
        }

    }

    interface DiveListItemListeners {
        fun onDiveClickListener(item: LogbookDive)
    }

    class DiffUtilCallBack : DiffUtil.ItemCallback<LogbookDive>() {
        override fun areItemsTheSame(oldItem: LogbookDive, newItem: LogbookDive): Boolean {
            return oldItem.logbookDiveEntity.logbookDiveId == newItem.logbookDiveEntity.logbookDiveId
        }

        override fun areContentsTheSame(oldItem: LogbookDive, newItem: LogbookDive): Boolean {
            //FIXME Probable cause of BUG - Issue #7 After Creation/Edit field data in ViewHolder of Recycler does not match displayed info.
            return oldItem.logbookDiveEntity.diveId == newItem.logbookDiveEntity.diveId &&
                    oldItem.logbookDiveEntity.diveNumber == newItem.logbookDiveEntity.diveNumber //&& oldItem.diveData == newItem.diveData
        }

    }
}