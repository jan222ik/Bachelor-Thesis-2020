package com.github.jan222ik.divelogbook.ui.fragments.menu

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import kotlinx.android.synthetic.main.fragment_main.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.delay


class MainFragment : Fragment() {

    lateinit var navController: NavController

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_main, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        requireActivity().onBackPressedDispatcher.addCallback(this, DoubleBackExit(activity!!, lifecycleScope))
        logbooksCard.setOnClickListener { navController.navigate(R.id.action_mainFragment_to_experimentBaseFragment) }
        diveListCard.setOnClickListener { navController.navigate(R.id.action_mainFragment_to_divePagedListFragment) }
        buddiesCard.setOnClickListener { navController.navigate(R.id.action_mainFragment_to_reusableEntriesMenuFragment) }
        statisticsCard.setOnClickListener { navController.navigate(R.id.action_mainFragment_to_statisticsFragment) }
    }

    class DoubleBackExit(private val activity: Activity, private val coroutineScope: CoroutineScope) : OnBackPressedCallback(true) {
        private var first = true
        private lateinit var async: Deferred<Unit>
        private lateinit var toast: Toast

        override fun handleOnBackPressed() {
            if (first) {
                toast = Toast.makeText(activity, "Press again to exit!", Toast.LENGTH_SHORT)
                toast.show()
                async = coroutineScope.async {
                    delay(2000L)
                    toast.cancel()
                }
                first = false
            } else {
                if (async.isActive) {
                    async.cancel()
                    toast.cancel()
                    activity.finish()
                } else {
                    first = true
                    handleOnBackPressed()
                }
            }
        }

    }

}