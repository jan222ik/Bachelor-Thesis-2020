package com.github.jan222ik.divelogbook.ui.fragments.edit.camera.experiment.experiments

import android.content.Context
import android.graphics.Bitmap
import com.github.jan222ik.divelogbook.ui.fragments.edit.camera.experiment.experiments.filters.Filter
import org.opencv.android.Utils
import org.opencv.core.Mat

class ThresholdGaussianExperiment(context: Context) : ExperimentBase(context) {

    override suspend fun process(image: Bitmap, experimentData: ExperimentData): ExperimentData {
        val startMillis = System.currentTimeMillis()
        val mat = Mat()
        Utils.bitmapToMat(image, mat)
        //val grayMat = Filter.greyscale(mat)
        //saveAsImage(convertMatToBitMap(grayMat)!!, "grey")
        val threshMat = Filter.adaptiveGaussianThreshold(mat)
        //val erodeMat = Filter.erode(threshMat)
        //saveAsImage(convertMatToBitMap(erodeMat)!!, "erode")
        //val sobelMat = Filter.sobel(threshMat)
        //saveAsImage( convertMatToBitMap(sobelMat)!!, "sobel")
        experimentData.timeMillisPreprocessing = System.currentTimeMillis().minus(startMillis)
        saveAsImage(convertMatToBitMap(threshMat)!!, "thresh_gaussian")
        return asyncAnalyseImage(convertMatToBitMap(threshMat)!!, experimentData)
    }


}