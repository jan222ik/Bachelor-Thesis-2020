package com.github.jan222ik.divelogbook.data.database.daos

import androidx.room.*
import com.github.jan222ik.divelogbook.data.database.entities.DiveCommentEntity

@Dao
abstract class DiveCommentDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun insert(commentEntity: DiveCommentEntity): Long

    @Update
    abstract suspend fun update(commentEntity: DiveCommentEntity)

    @Query("DELETE FROM DiveCommentEntity")
    abstract suspend fun deleteAll()

    @Query("DELETE FROM DiveCommentEntity Where commentId = :commentId")
    abstract suspend fun deleteById(commentId: Long)

    @Query("Select * FROM DiveCommentEntity Where commentId = :commentId")
    abstract suspend fun getById(commentId: Long): DiveCommentEntity

    suspend fun upsert(commentEntity: DiveCommentEntity?): Long? {
        if (commentEntity == null) return null
        return if (commentEntity.commentId == null) {
            if (commentEntity.comment.isNotEmpty()) {
                insert(commentEntity)
            } else null
        } else {
            if (commentEntity.comment.isNotEmpty()) {
                update(commentEntity)
                commentEntity.commentId
            } else {
                deleteById(commentEntity.commentId!!)
                null
            }
        }
    }
}