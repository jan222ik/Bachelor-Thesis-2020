package com.github.jan222ik.divelogbook.data.database.daos

import androidx.lifecycle.LiveData
import androidx.room.*
import com.github.jan222ik.divelogbook.data.database.entities.config.EditModuleConfigEntity

@Dao
interface EditModuleConfigEntriesDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(editModuleConfigEntity: EditModuleConfigEntity): Long

    @Update
    suspend fun update(editModuleConfigEntity: EditModuleConfigEntity)

    @Query("DELETE FROM EditModuleConfigEntity")
    suspend fun deleteAll()

    @Query("Select * FROM EditModuleConfigEntity Where configItemName = :editModuleConfigName")
    fun getByConfigName(editModuleConfigName: String): List<EditModuleConfigEntity>

    @Query("Select * FROM EditModuleConfigEntity")
    fun getAll(): List<EditModuleConfigEntity>
}