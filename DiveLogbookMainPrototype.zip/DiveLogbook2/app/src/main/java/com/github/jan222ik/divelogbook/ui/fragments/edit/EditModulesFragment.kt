package com.github.jan222ik.divelogbook.ui.fragments.edit

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import androidx.navigation.NavDirections
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.ui.viewmodel.EditModuleItemData
import com.github.jan222ik.divelogbook.ui.viewmodel.EditViewModel
import com.github.jan222ik.divelogbook.ui.viewmodel.LogbookViewModel
import com.google.android.material.card.MaterialCardView
import kotlinx.android.synthetic.main.fragment_edit_modules.view.*
import kotlinx.android.synthetic.main.fragment_edit_modules_item.view.*
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.runBlocking
import kotlin.reflect.KFunction1


class EditModulesFragment : Fragment() {

    private lateinit var editViewModel: EditViewModel
    private lateinit var logbookViewModel: LogbookViewModel
    private lateinit var navController: NavController

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_edit_modules, container, false)
        editViewModel = ViewModelProviders.of(requireActivity()).get(EditViewModel::class.java)
        logbookViewModel = ViewModelProviders.of(requireActivity()).get(LogbookViewModel::class.java)
        editViewModel.initModuleData()
        with(view.moduleList as RecyclerView) {
            layoutManager = LinearLayoutManager(context)
            val realAdapter = EditModulesListAdapter(this@EditModulesFragment::nav)
            adapter = realAdapter
            editViewModel.moduleListData.observe(requireActivity(), Observer {
                realAdapter.setData(it)
                println("Update viewmodel list modules ${it.size}")
            })
            editViewModel.moduleListConfigName.postValue(null)
        }
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        val currentChainNavDirection = editViewModel.getCurrentChainNavDirection()
        if (currentChainNavDirection != null) {navController.navigate(currentChainNavDirection)}

        view.finishEditBtn.setOnClickListener {
            runBlocking(IO) {
                editViewModel.save()
                logbookViewModel.invalidateDives()
            }
            navController.navigate(EditModulesFragmentDirections.actionEditModulesFragmentToEditConfirmationFragment())
        }

    }

    private fun nav(dest: NavDirections) {
        navController.navigate(dest)
    }


    class EditModulesListAdapter(private val navHandle: KFunction1<NavDirections, Unit>) : RecyclerView.Adapter<EditModulesListAdapter.VH>() {

        private var data: List<EditModuleItemData> = listOf()

        fun setData(newList: List<EditModuleItemData>) {
            data = newList.sortedBy { it.orderNumber }
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val materialCardView = LayoutInflater.from(parent.context)
                .inflate(R.layout.fragment_edit_modules_item, parent, false) as MaterialCardView
            return VH(materialCardView)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            holder.root.editModuleName.text = data[position].name
            holder.root.setOnClickListener { navHandle(data[position].direction) }
        }

        override fun getItemCount() = data.size

        class VH(val root: MaterialCardView) : RecyclerView.ViewHolder(root)
    }
}