package com.github.jan222ik.divelogbook.ui.viewmodel

data class Filter(
    var isAndMode: Boolean = false,
    var numberStart: Int? = null,
    var numberEnd: Int? = null,

    // Location
    var country: String? = null
) {
    val numberDisplayString: String
        get() {
            return when { //!!! Case order is semantic
                numberStart != null && numberEnd != null && numberStart == numberEnd -> numberStart!!.toString()
                numberStart != null && numberEnd != null -> "$numberStart-$numberEnd"
                numberStart == null && numberEnd == null -> ""
                numberStart == null ->  "-$numberEnd"
                numberEnd == null ->  "$numberStart-"
                else -> ""
            }
        }

    var general: String? = null
}