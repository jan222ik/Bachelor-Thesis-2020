package com.github.jan222ik.divelogbook.ui.fragments.edit

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.activity.addCallback
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.database.db.toDbDepth
import com.github.jan222ik.divelogbook.data.updateAsUser
import com.github.jan222ik.divelogbook.ui.viewmodel.EditViewModel
import kotlinx.android.synthetic.main.fragment_edit_common_nav.view.*
import kotlinx.android.synthetic.main.fragment_edit_depth.view.*


class EditDepthFragment : Fragment() {

    lateinit var navController: NavController
    lateinit var editViewModel: EditViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner) {
            editViewModel.setPreviousChainFragment {
                navController.popBackStack()
            }
            navController.navigateUp()
        }
        return inflater.inflate(R.layout.fragment_edit_depth, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        editViewModel = ViewModelProviders.of(activity!!).get(EditViewModel::class.java)
        view.nextBtn.setOnClickListener {
            with(editViewModel.depthEdit) {
                max = max.updateAsUser(view.editTextDepthMax.textString.safeDouble()?.toDbDepth())
                avg = avg.updateAsUser(view.editTextDepthAvg.textString.safeDouble()?.toDbDepth())
            }
            editViewModel.setNextChainFragment()
            navController.navigate(EditDepthFragmentDirections.actionEditDepthFragmentToEditModulesFragment())
        }

        val depth = editViewModel.depthEdit
        with(view) {
            editTextDepthMax.textString = depth.max.value.toViewMeters().toBlankStringOnNull()
            MaterialTextHelper.apply(depth.max, "m", depthMaxLayout, resources)

            editTextDepthAvg.textString = depth.avg.value.toViewMeters().toBlankStringOnNull()
            MaterialTextHelper.apply(depth.avg, "m", depthAvgLayout, resources)
        }
    }

    private var EditText.textString
        get() = this.text.toString()
        set(value) = this.setText(value)

    private fun Any?.toBlankStringOnNull(): String = this?.toString() ?: ""
    private fun Int?.toViewMeters() = if (this != null) this / 10.toDouble() else null


}