package com.github.jan222ik.divelogbook.data

fun Int?.m(truncCm: Boolean = false): String {
    return if (this != null) {
        val cmRemaining = (this.rem(10))
        val out = (this / 10).toString()
        if (!truncCm && cmRemaining > 0) {
            out.plus(",$cmRemaining m")
        } else out.plus(" m")
    } else ""
}

fun Int?.minWithSec(): String {
    var out = ""
    if (this != null) {
        out = (this / 60).toString().plus(" min")
        val secRemain = this.rem(60)
        if (secRemain > 0) {
            out.plus(" ").plus(secRemain).plus(" s")
        }
    }
    return out
}

fun Long?.minWithSec(): String {
    var out = ""
    if (this != null) {
        out = (this / 60).toString().plus(" min")
        val secRemain = this.rem(60)
        if (secRemain > 0) {
            out.plus(" ").plus(secRemain).plus(" s")
        }
    }
    return out
}

fun Long?.hrsWithMin(): String {
    var out = ""
    if (this != null) {
        val totalMin = this / 60
        out = (totalMin / 60).toString().plus(" h")
        val minRemain = totalMin.rem(60)
        if (minRemain > 0) {
            out.plus(" ").plus(minRemain).plus(" min")
        }
    }
    return out
}

fun Long?.daysWithHrsAndMin(): String {
    var out = ""
    if (this != null) {
        val totalMin = this / 60
        val totalHrs = totalMin / 60
        val totalDays= totalHrs / 24
        if (totalDays > 0) {
            out = totalDays.toString().plus(" d")
        }
        val hrsRemain = totalMin.rem(60)
        if (hrsRemain > 0) {
            out.plus(" ").plus(hrsRemain).plus(" h")
        }
        val minRemain = totalMin.rem(60)
        if (minRemain > 0) {
            out.plus(" ").plus(minRemain).plus(" min")
        }
    }
    return out
}