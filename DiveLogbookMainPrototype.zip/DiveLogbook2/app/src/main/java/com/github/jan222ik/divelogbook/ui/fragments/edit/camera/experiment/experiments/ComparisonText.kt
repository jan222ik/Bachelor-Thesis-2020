package com.github.jan222ik.divelogbook.ui.fragments.edit.camera.experiment.experiments

sealed class ComparisonText(open val text: String, open val name: String) {
    data class Words20Ipsum(override val text: String = "Lorem ipsum dolor sit amet,\nconsetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et\ndolore magna aliquyam") : ComparisonText(text, "Words20Ipsum")
    data class ThreeMetrics(override val text: String = "Depth: 18,8 m\nDuration: 70 min\nEntry time: 10:34") : ComparisonText(text, "Three Metrics")
    data class MetricDateWritten(override val text: String = "Date: 20.06.2020") : ComparisonText(text, "MetricDateWritten")
}