package com.github.jan222ik.divelogbook.data.database.db

/**
 * Lazy offers assignable lazy functionality.
 *
 * @param T defines the value type
 * @param D defines the type of a dependency
 *
 * The class provides three implementations which can be instantiated through Lazy's companion object.
 * 1. of : Used for T
 * 2. ofNullable : Used for T?
 * 3. ofInitial: Used if no lazy is needed, but Lazy<T,D> is used as a backing property.
 *
 * @author Janik Mayr
 */
sealed class Lazy<T, D> {
    /**
     * Returns latest loaded value or load it through given means.
     * @return T type of value
     */
    abstract fun get(): T

    /**
     * Overwrites the present value and prohibits loading from given means.
     * @param value to set
     */
    abstract fun set(value: T)

    companion object {
        fun <T, D> of(dependency: D, onLoad: (D) -> T): Lazy<T, D> {
            return LazyImpl(dependency, onLoad)
        }

        fun <T, D> ofNullable(dependency: D, onLoad: (D) -> T?): Lazy<T?, D> {
            return LazyImplNullable(dependency, onLoad)
        }

        fun <T, D> ofInitial(init: T? = null): Lazy<T?, D> {
            return LazyImplWithInitial(init)
        }
    }

    private class LazyImplWithInitial<T, D>(private var loaded: T? = null) : Lazy<T?, D>() {
        override fun get(): T? = loaded
        override fun set(value: T?) {
            loaded = value
        }
    }

    private class LazyImpl<T, D>(
        private val dependency: D,
        private val onLoad: (D) -> T
    ) : Lazy<T, D>() {

        private var wasLoaded = false
        private var loaded: T? = null

        override fun get(): T {
            if (!wasLoaded) {
                wasLoaded = true
                loaded = onLoad(dependency)
            }
            return loaded!!
        }

        override fun set(value: T) {
            wasLoaded = true
            loaded = value
        }

    }

    private class LazyImplNullable<T, D>(
        private val dependency: D,
        private val onLoad: (D) -> T?
    ) : Lazy<T?, D>() {

        private var wasLoaded = false
        private var loaded: T? = null

        override fun get(): T? {
            if (!wasLoaded) {
                wasLoaded = true
                loaded = onLoad(dependency)
            }
            return loaded
        }

        override fun set(value: T?) {
            wasLoaded = true
            loaded = value
        }

    }
}
