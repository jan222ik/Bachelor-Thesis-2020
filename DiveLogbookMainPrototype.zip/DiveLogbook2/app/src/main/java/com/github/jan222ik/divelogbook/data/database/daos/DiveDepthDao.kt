package com.github.jan222ik.divelogbook.data.database.daos

import androidx.room.*
import com.github.jan222ik.divelogbook.data.database.entities.DiveDepthEntity

@Dao
interface DiveDepthDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(depthEntity: DiveDepthEntity): Long

    @Update
    suspend fun update(depthEntity: DiveDepthEntity)

    @Query("DELETE FROM DiveDepthEntity")
    suspend fun deleteAll()

    @Query("DELETE FROM DiveDepthEntity Where depthId = :depthId")
    suspend fun deleteById(depthId: Long)

    @Query("Select * FROM DiveDepthEntity Where depthId = :depthId")
    suspend fun getById(depthId: Long): DiveDepthEntity
}