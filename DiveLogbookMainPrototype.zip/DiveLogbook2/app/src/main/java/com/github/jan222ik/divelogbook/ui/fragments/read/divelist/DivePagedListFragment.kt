package com.github.jan222ik.divelogbook.ui.fragments.read.divelist

import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.EditText
import androidx.core.widget.doOnTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.database.pojos.LogbookDive
import com.github.jan222ik.divelogbook.ui.ChipGroupManager
import com.github.jan222ik.divelogbook.ui.viewmodel.LogbookViewModel
import com.github.jan222ik.divelogbook.ui.viewmodel.SearchEvaluator
import kotlinx.android.synthetic.main.dialog_filter.*
import kotlinx.android.synthetic.main.fragment_dive_pagedlist_list.view.*


class DivePagedListFragment : Fragment(), PagedAdapter.DiveListItemListeners {

    private val searchEvaluator = SearchEvaluator()

    private lateinit var navController: NavController
    private lateinit var model: LogbookViewModel


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        val view = inflater.inflate(R.layout.fragment_dive_pagedlist_list, container, false)
        model = ViewModelProviders.of(requireActivity()).get(LogbookViewModel::class.java)

        with(view.list as RecyclerView) {
            layoutManager = LinearLayoutManager(context)
            val realAdapter = PagedAdapter(this@DivePagedListFragment)
            adapter = realAdapter

            model.initDives()
            emptyHandles(false, view)
            loadingHandles(true, view)
            model.allDives!!.observe(requireActivity(), Observer {
                Log.d("TAG", "onCreateView: Data refresh")
                realAdapter.submitList(it)
                emptyHandles((it.size < 1), view)
                loadingHandles(false, view)
            })
            model.applyLatestFilter()
        }
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        navController = Navigation.findNavController(view)

        // Setup "Create New Entry" Button
        view.fab.setOnClickListener {
            model.setEdit(null)
            navController.navigate(R.id.action_divePagedListFragment_to_editDiveHostFragment)
        }

        view.importCsvBtn.setOnClickListener {
            navController.navigate(DivePagedListFragmentDirections.actionDivePagedListFragmentToImportCSVFragment())
        }

        // Setup Chips for Filter
        val latestFilter = model.latestFilter
        val chipGroupManager = ChipGroupManager(view.quickFilterChipGroup)
        // Filter Mode Chip
        val modeChip =
            chipGroupManager.mappedElement(value = latestFilter?.isAndMode ?: false, prefix = "Mode: ") { if (it) "AND" else "OR" }
                .also {
                    it.setOnClickListener {
                        it.update(searchEvaluator.changeMode())
                        model.updateFilter(searchEvaluator.filter)
                    }
                }
        // Filter Range Chip
        val rangeChip = chipGroupManager.mappedElement(value = latestFilter?.numberDisplayString, prefix = "№: ")

        // Link to observable filter in Model
        model.allDivesFilter.observe(requireActivity(), Observer {
            chipGroupManager.clearGroup()
            modeChip.update(it?.isAndMode ?: false)
            rangeChip.update(it?.numberDisplayString)
        })

        // Setup Create Dialog for Filter
        view.filterByGPSBtn.setOnClickListener {
            showFilterDialog()
        }

    }

    private fun emptyHandles(vis: Boolean, view: View) {
        val visibility = if (vis) View.VISIBLE else View.GONE
        view.emptyListContext.visibility = visibility
    }

    private fun loadingHandles(vis: Boolean, view: View) {
        val visibility = if (vis) View.VISIBLE else View.GONE
        view.loadingListContext.visibility = visibility
    }

    override fun onDiveClickListener(item: LogbookDive) {
        model.setDetail(item)
        navController.navigate(R.id.action_divePagedListFragment_to_defaultDetailsFragment)
    }

    private fun showFilterDialog() {
        val dialog = Dialog(requireActivity())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_filter)

        val chipGroupManager = ChipGroupManager(dialog.filterChipGroup)

        // Init Mode
        val andMode = model.latestFilter?.isAndMode ?: false
        dialog.modeToggleGroup.check(if (andMode) R.id.andModeButton else R.id.orModeButton)
        val modeChip = chipGroupManager.mappedElement(andMode, "Mode: ") {
            if (it) "AND" else "OR"
        }
        dialog.modeToggleGroup.addOnButtonCheckedListener { _, id, c ->
            if (c) {
                modeChip.update(id == R.id.andModeButton)
            }
        }

        // Init NumberRange
        val numberRangeInit = model.latestFilter?.numberDisplayString ?: ""
        dialog.diveNumberRange.textString = numberRangeInit
        val numberRangeChip = chipGroupManager.mappedElement(numberRangeInit, "№: ")
        dialog.diveNumberRange.doOnTextChanged { text, _, _, _ -> numberRangeChip.update(text?.toString()) }

        //Init General
        dialog.generalDiveSearch.textString = model.latestFilter?.general ?: ""


        dialog.applyButton.setOnClickListener {
            val generalString = dialog.generalDiveSearch.textString
            val numberRange = dialog.diveNumberRange.textString
            val isOR = dialog.modeToggleGroup.checkedButtonId == R.id.orModeButton
            searchEvaluator.addGeneralInputString(generalString)
            searchEvaluator.addDiveNumberRangeInput(numberRange)
            searchEvaluator.changeMode(!isOR)
            model.updateFilter(searchEvaluator.filter)
            dialog.dismiss()
        }
        dialog.show()
    }


    private var EditText.textString
        get() = this.text.toString()
        set(value) = this.setText(value)

}
