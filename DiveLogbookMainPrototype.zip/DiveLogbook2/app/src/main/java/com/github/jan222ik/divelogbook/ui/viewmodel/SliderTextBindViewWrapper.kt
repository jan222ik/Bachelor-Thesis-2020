package com.github.jan222ik.divelogbook.ui.viewmodel

import android.widget.EditText
import androidx.core.widget.doOnTextChanged
import com.google.android.material.slider.Slider
import kotlin.math.roundToInt

class SliderTextBindViewWrapper(
    private val slider: Slider,
    private val editText: EditText,
    var value: Float,
    private val onValueChange: (Float) -> Unit
) {

    init {
        slider.addOnChangeListener { _, new, fromUser ->
            if (fromUser) {
                value = new.roundToInt().toFloat()
                editText.setText(value.toString())
                onValueChange(value)
            }
        }
        editText.doOnTextChanged { text, _, _, _ ->
            value = text.toString().toFloat().roundToInt().toFloat()
            slider.value = value
            onValueChange(value)
        }
        slider.value = value
        editText.setText(value.toString())
    }
}