package com.github.jan222ik.divelogbook.ui.fragments.edit.camera

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.github.jan222ik.divelogbook.ui.fragments.edit.camera.googlelib.GraphicOverlay
import com.google.firebase.ml.vision.text.FirebaseVisionText


class OutlineGraphic(
    overlay: GraphicOverlay,
    private val block: FirebaseVisionText.TextBlock
) : GraphicOverlay.Graphic(overlay) {

    private val rectPaint = Paint().apply {
        color = TEXT_COLOR
        style = Paint.Style.STROKE
        strokeWidth = STROKE_WIDTH
    }

    private val textPaint = Paint().apply {
        color = TEXT_COLOR
        textSize = TEXT_SIZE
    }

    override fun draw(canvas: Canvas) {
        block.let {
            val rect = RectF(it.boundingBox)
            val rect2 = RectF(it.boundingBox)
            rect.left = translateX(rect.left)
            rect.top = translateY(rect.top)
            rect.right = translateX(rect.right)
            rect.bottom = translateY(rect.bottom)
            println("Draw (L${rect.left}, T${rect.top});(R${rect.right}, B${rect.bottom})")
            println("Draw Offset: (L${rect2.left - rect.left}, T${rect2.top - rect.top});(R${rect2.right - rect.right}, B${rect2.bottom - rect.bottom})")
            canvas.drawRect(rect, rectPaint)
            canvas.drawText(it.text, rect.left, rect.bottom, textPaint)
        }

        /*
        text?.let { txt ->
            // Draws the bounding box around the TextBlock.
            val rect = RectF(txt.boundingBox)
            rect.left = translateX(rect.left)
            rect.top = translateY(rect.top)
            rect.right = translateX(rect.right)
            rect.bottom = translateY(rect.bottom)
            canvas.drawRect(rect, rectPaint)

            // Renders the text at the bottom of the box.
            canvas.drawText(txt.text, rect.left, rect.bottom, textPaint)
        } ?: kotlin.run { throw IllegalStateException("Attempting to draw a null text.") }

         */
    }

    companion object {

        private const val TEXT_COLOR = Color.WHITE
        private const val TEXT_SIZE = 54.0f
        private const val STROKE_WIDTH = 4.0f
    }
}