package com.github.jan222ik.divelogbook.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.daysWithHrsAndMin
import com.github.jan222ik.divelogbook.ui.viewmodel.StatisticViewModel
import kotlinx.android.synthetic.main.fragment_statistics.view.*

class StatisticsFragment : Fragment() {

    lateinit var viewModel: StatisticViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_statistics, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProviders.of(activity!!).get(StatisticViewModel::class.java)

        val cumulativeBaseTime = viewModel.cumulativeBaseTime()
        cumulativeBaseTime.observe(viewLifecycleOwner, Observer {
            with(view) {
                statCumulativeBaseTime.text = it.daysWithHrsAndMin()
            }
        })
        val listOf = listOf("in m   ", "in cm  ", "in m,cm")
        with(view.testItemLayout) {
            suffixText = listOf[0]
            suffixTextView.setOnClickListener { suffixText = listOf[listOf.indexOf(suffixText.toString()).inc().rem(listOf.size)] }
        }
    }
}