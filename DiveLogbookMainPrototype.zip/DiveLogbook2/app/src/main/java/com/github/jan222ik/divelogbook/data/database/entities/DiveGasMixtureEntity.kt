package com.github.jan222ik.divelogbook.data.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class DiveGasMixtureEntity(
    var barStart: Int? = null,
    var barEnd: Int? = null,
    var tankSize: Int? = null,
    var mixtureType: Byte? = null,
    var o2: Int? = null
) {
    @PrimaryKey(autoGenerate = true)
    var gaxMixtureId: Long? = null
}