package com.github.jan222ik.divelogbook.data.repo

import com.github.jan222ik.divelogbook.data.database.daos.*
import com.github.jan222ik.divelogbook.data.database.db.Lazy
import com.github.jan222ik.divelogbook.data.database.entities.DiveEntity
import com.github.jan222ik.divelogbook.data.database.entities.DiveLocationEntity
import com.github.jan222ik.divelogbook.data.database.pojos.SingleDiveData
import kotlinx.coroutines.runBlocking

class SingleDiveDataRepo(
    private val diveEntityDao: DiveEntityDao,
    private val diveDepthDao: DiveDepthDao,
    private val diveTemporalDao: DiveTemporalDao,
    private val diveSpotDao: DiveSpotDao,
    private val diveLocationDao: DiveLocationDao,
    private val diveCommentDao: DiveCommentDao,
    private val diveGasMixtureDao: DiveGasMixtureDao,
    private val addressDao: AddressDao
) {

    suspend fun getSingleDiveDataById(id: Long): SingleDiveData {
        val data = diveEntityDao.getSingleById(id)

        if (data.diveEntity?.locationId != null) {
            val location = diveLocationDao.getPojoById(data.diveEntity!!.locationId!!)
            data.location = location
        }

        data.gasMixtureLazy = Lazy.ofNullable(diveGasMixtureDao) lazyGasMix@{
            val gasMixtureId = data.diveEntity?.gasMixtureId
            return@lazyGasMix if (gasMixtureId == null) null else runBlocking {
                it.getById(gasMixtureId)
            }
        }

        data.commentLazy = Lazy.ofNullable(diveCommentDao) lazyComment@{
            val commentId = data.diveEntity?.commentId
            return@lazyComment if (commentId == null) null else runBlocking {
                it.getById(commentId)
            }
        }

        return data
    }

    private suspend fun insert(dive: SingleDiveData): Long {
        val depthId = diveDepthDao.insert(dive.depth)
        val temporalId = diveTemporalDao.insert(dive.temporal)
        val locationId = dive.location?.entity?.locationId
        val commentId = diveCommentDao.upsert(dive.comment)
        return diveEntityDao.insert(DiveEntity(temporalId, depthId, locationId, commentId))
    }

    private suspend fun update(dive: SingleDiveData): Long {
        diveDepthDao.update(dive.depth)
        diveTemporalDao.update(dive.temporal)
        if (dive.location != null) {
            diveSpotDao.update(dive.location!!.spot)
            if (dive.location!!.address != null) {
                addressDao.update(dive.location!!.address!!)
            }
            val also = DiveLocationEntity(
                dive.location!!.spot.spotId!!,
                dive.location!!.address?.addressId!!
            ).also { it.locationId = dive.location!!.entity.locationId }
            diveLocationDao.update(also)
        } else {
            if (dive.diveEntity!!.locationId != null) {
                dive.diveEntity!!.locationId = null
                //Location could be deleted
            }
        }

        dive.diveEntity!!.commentId = diveCommentDao.upsert(dive.comment)

        diveEntityDao.update(dive.diveEntity!!)
        return dive.diveEntity!!.depthId
    }

    suspend fun upsert(dive: SingleDiveData): Long {
        return if (dive.diveEntity == null) {
            insert(dive)
        } else {
            update(dive)
        }
    }

}