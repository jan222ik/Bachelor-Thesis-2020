package com.github.jan222ik.divelogbook.ui.fragments.edit.camera.experiment.experiments

import android.content.Context
import android.graphics.Bitmap

class RawExperiment(context: Context) : ExperimentBase(context) {

    override suspend fun process(image: Bitmap, experimentData: ExperimentData): ExperimentData {
        return asyncAnalyseImage(image, experimentData)
    }


}