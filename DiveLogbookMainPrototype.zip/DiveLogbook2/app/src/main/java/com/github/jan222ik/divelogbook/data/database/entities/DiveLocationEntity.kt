package com.github.jan222ik.divelogbook.data.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity
data class DiveLocationEntity(
    @ForeignKey(parentColumns = ["spotEntityId"], childColumns = ["spotId"], entity = DiveSpotEntity::class)
    val spotEntityId: Long,
    @ForeignKey(parentColumns = ["addressEntityId"], childColumns = ["addressId"], entity = AddressEntity::class)
    val addressEntityId: Long?
) {
    @PrimaryKey(autoGenerate = true)
    var locationId: Long? = null
}
