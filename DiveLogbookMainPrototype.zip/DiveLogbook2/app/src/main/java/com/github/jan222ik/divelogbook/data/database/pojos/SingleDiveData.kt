package com.github.jan222ik.divelogbook.data.database.pojos

import androidx.room.Embedded
import androidx.room.Ignore
import androidx.room.Relation
import com.github.jan222ik.divelogbook.data.database.daos.DiveCommentDao
import com.github.jan222ik.divelogbook.data.database.daos.DiveEntityDao
import com.github.jan222ik.divelogbook.data.database.daos.DiveGasMixtureDao
import com.github.jan222ik.divelogbook.data.database.db.Lazy
import com.github.jan222ik.divelogbook.data.database.entities.*

data class SingleDiveData(
    @Embedded var diveEntity: DiveEntity? = null,

    @Relation(
        parentColumn = "depthFK",
        entityColumn = "depthId"
    )
    val depth: DiveDepthEntity,

    @Relation(
        parentColumn = "temporalFK",
        entityColumn = "diveTemporalId"
    )
    val temporal: DiveTemporalEntity

) {
    @Ignore
    var location: DiveLocation? = null


    @Ignore
    var gasMixtureLazy: Lazy<DiveGasMixtureEntity?, DiveGasMixtureDao>? = null
    var gasMixture: DiveGasMixtureEntity?
        get() = gasMixtureLazy!!.get()
        set(value) = gasMixtureLazy!!.set(value)


    @Ignore
    var commentLazy: Lazy<DiveCommentEntity?, DiveCommentDao>? = null
    var comment: DiveCommentEntity?
        get() = commentLazy!!.get()
        set(value) = commentLazy!!.set(value)

    @Ignore
    var ratingLazy: Lazy<DiveRatingEntity?, DiveEntityDao>? = null
    var rating: DiveRatingEntity?
        get() = ratingLazy!!.get()
        set(value) = ratingLazy!!.set(value)

}