package com.github.jan222ik.divelogbook.data.database.pojos

import androidx.room.Embedded
import androidx.room.Relation
import com.github.jan222ik.divelogbook.data.database.entities.AddressEntity
import com.github.jan222ik.divelogbook.data.database.entities.DiveLocationEntity
import com.github.jan222ik.divelogbook.data.database.entities.DiveSpotEntity

data class DiveLocation(
    @Embedded val entity: DiveLocationEntity,
    @Relation(
        parentColumn = "spotEntityId",
        entityColumn = "spotId"
    )
    val spot: DiveSpotEntity,
    @Relation(
        parentColumn = "addressEntityId",
        entityColumn = "addressId"
    )
    val address: AddressEntity?
)