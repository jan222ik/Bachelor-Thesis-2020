package com.github.jan222ik.divelogbook.ui.fragments.edit.camera.experiment.experiments

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.google.firebase.ml.common.FirebaseMLException
import com.google.firebase.ml.vision.FirebaseVision
import com.google.firebase.ml.vision.common.FirebaseVisionImage
import com.google.firebase.ml.vision.text.FirebaseVisionText
import org.opencv.android.Utils
import org.opencv.core.CvException
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine


abstract class ExperimentBase(val context: Context) {
    open fun setUp() {}
    abstract suspend fun process(image: Bitmap, experimentData: ExperimentData): ExperimentData
    open fun teardown() {}

    suspend fun startExperiment(name: String, image: Bitmap, comparisonText: ComparisonText, repetitions: Int): List<ExperimentData> {
        val resultData: MutableList<ExperimentData> = mutableListOf()
        setUp()
        for (i in 0 until repetitions) {
            val data = process(image, ExperimentData(name, i, comparisonText))
            resultData.add(data)
        }
        teardown()
        return resultData
    }


    fun analyseImage(imageBitmap: Bitmap, onResult: (FirebaseVisionText, Long) -> Unit) {
        val image = FirebaseVisionImage.fromBitmap(imageBitmap)
        val detector = FirebaseVision.getInstance().onDeviceTextRecognizer
        val startTime = System.currentTimeMillis()
        detector.processImage(image)
            .addOnSuccessListener { onResult(it, System.currentTimeMillis() - startTime) }
            .addOnFailureListener { e ->
                Log.d("Experiment Base", "analyzeImage: Fail ML")
                if (e is FirebaseMLException && e.code == FirebaseMLException.UNAVAILABLE) {
                    Log.d("Experiment Base", "analyseImage: Downloading")
                } else {
                    throw e
                }
            }

    }

    suspend fun asyncAnalyseImage(image: Bitmap, experimentData: ExperimentData): ExperimentData {
        return suspendCoroutine { continuation ->
            val callback = { result: FirebaseVisionText, timeMillis: Long ->
                with(experimentData) {
                    recognizedText = result
                    textString = result.text
                    timeMillisAnalyser = timeMillis
                    timeMillisPreprocessing = 0
                }
                continuation.resume(experimentData)
            }
            analyseImage(image, callback)
        }
    }

    internal fun convertMatToBitMap(input: Mat): Bitmap? {
        val local = Mat()
        input.copyTo(local)
        var bmp: Bitmap? = null
        val rgb = Mat()
        Imgproc.cvtColor(local, rgb, Imgproc.COLOR_BGR2RGB)
        try {
            bmp = Bitmap.createBitmap(rgb.cols(), rgb.rows(), Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(rgb, bmp)
        } catch (e: CvException) {
            Log.d("Exception", e.message)
        }
        return bmp
    }

    internal fun saveAsImage(bmp: Bitmap, nameSuffix: String = "") {
        context.openFileOutput("0_$nameSuffix${bmp.hashCode()}.png", Context.MODE_PRIVATE).use {
            bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
        }
    }
}

data class ExperimentData(val name: String, val repetition: Int, val comparisonText: ComparisonText) {
    var levenshteinDistance: Int? = null
    var recognizedText: FirebaseVisionText? = null
    var textString: String? = null
    var timeMillisAnalyser: Long? = null
    var timeMillisPreprocessing: Long? = null

    override fun toString(): String {
        return "ExperimentData(name='$name', repetition=$repetition, comparisonText=${comparisonText.name}, levenshteinDistance=$levenshteinDistance, textString=${textString?.length}, timeMillisAnalyser=$timeMillisAnalyser, timeMillisPostprocessing=$timeMillisPreprocessing)"
    }


}