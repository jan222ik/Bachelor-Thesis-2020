package com.github.jan222ik.divelogbook.ui

import android.content.Context
import android.view.View
import androidx.core.view.contains
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

typealias ValueMapping <T> = (T) -> String

class ChipGroupManager(private val group: ChipGroup) {

    fun clearGroup() {
        group.removeAllViews()
    }

    fun <T> mappedElement(value: T? = null, prefix: String = "", valueMapping: ValueMapping<T> = { v -> v.toString()}): ChipGroupElement<T> {
        val chipGroupElement = ChipGroupElement(group.context, group, prefix, valueMapping)
        if (value != null) {
            chipGroupElement.update(value)
        }
        return chipGroupElement
    }

}

class ChipGroupElement<T> internal constructor(
    context: Context,
    private val group: ChipGroup,
    private val prefix: String,
    private val valueMapping: ValueMapping<T>
) {
    private val chip: Lazy<Chip> = lazy { Chip(context) }

    fun update(value: T?) {
        if (value != null) {
            val valueMapping = valueMapping(value)
            if (valueMapping.isNotEmpty()) {
                if (!group.contains(chip.value)) {
                    group.addView(chip.value)
                }
                chip.value.text = prefix + valueMapping
            } else remove()
        } else remove()
    }

    fun remove() {
        if (chip.isInitialized()) {
            group.removeView(chip.value)
        }
    }

    fun setOnClickListener(l: () -> Unit) {
        chip.value.setOnClickListener { l() }
    }
}