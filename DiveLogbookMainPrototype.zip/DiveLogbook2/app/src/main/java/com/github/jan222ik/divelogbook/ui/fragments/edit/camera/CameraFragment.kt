package com.github.jan222ik.divelogbook.ui.fragments.edit.camera

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.hardware.display.DisplayManager
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.util.Size
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.Toast
import androidx.camera.core.*
import androidx.camera.core.ImageCapture.Metadata
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.LifecycleOwner
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.Edit
import com.github.jan222ik.divelogbook.ui.activities.KEY_EVENT_ACTION
import com.github.jan222ik.divelogbook.ui.activities.KEY_EVENT_EXTRA
import com.github.jan222ik.divelogbook.ui.activities.MainActivity
import com.github.jan222ik.divelogbook.ui.viewmodel.EditViewModel
import com.google.android.gms.tasks.Task
import com.google.android.material.snackbar.Snackbar
import com.google.common.util.concurrent.ListenableFuture
import com.google.firebase.ml.common.FirebaseMLException
import com.google.firebase.ml.vision.FirebaseVision
import com.google.firebase.ml.vision.common.FirebaseVisionImage
import com.google.firebase.ml.vision.common.FirebaseVisionImageMetadata
import com.google.firebase.ml.vision.text.FirebaseVisionText
import kotlinx.android.synthetic.main.fragment_camera_preview.*
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeParseException
import java.util.*
import java.util.concurrent.Executor
import java.util.concurrent.Executors
import kotlin.collections.ArrayList
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Helper type alias used for analysis use case callbacks */
typealias LumaListener = (luma: Double) -> Unit

typealias TextPreviewListener = (firebaseText: FirebaseVisionText) -> Unit
typealias MLDownloadingExceptionListener = (e: FirebaseMLException) -> Unit
typealias AnalysisSizeListener = (Size) -> Unit

/**
 * Main fragment for this app. Implements all camera operations including:
 * - Viewfinder
 * - Photo taking
 * - Image analysis
 */
class CameraFragment : Fragment() {

    private lateinit var container: FrameLayout
    private lateinit var viewFinder: PreviewView
    private lateinit var outputDirectory: File
    private lateinit var broadcastManager: LocalBroadcastManager
    private lateinit var displayManager: DisplayManager
    private lateinit var mainExecutor: Executor
    private lateinit var analysisExecutor: Executor

    private var displayId: Int = -1
    private var lensFacing: Int = CameraSelector.LENS_FACING_BACK
    private var preview: Preview? = null
    private var imageCapture: ImageCapture? = null
    private var imageAnalyzer: ImageAnalysis? = null
    private var camera: Camera? = null


    /** Volume down button receiver used to trigger shutter */
    private val volumeDownReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.getIntExtra(KEY_EVENT_EXTRA, KeyEvent.KEYCODE_UNKNOWN)) {
                // When the volume down button is pressed, simulate a shutter button click
                KeyEvent.KEYCODE_VOLUME_DOWN -> {
                    val shutter = container.findViewById<ImageButton>(R.id.camera_capture_button)
                    shutter.simulateClick()
                }
            }
        }
    }

    /**
     * We need a display listener for orientation changes that do not trigger a configuration
     * change, for example if we choose to override config change in manifest or for 180-degree
     * orientation changes.
     */
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = Unit
        override fun onDisplayRemoved(displayId: Int) = Unit
        override fun onDisplayChanged(displayId: Int) = view?.let { view ->
            if (displayId == this@CameraFragment.displayId) {
                Log.d(TAG, "Rotation changed: ${view.display.rotation}")
                imageCapture?.setTargetRotation(view.display.rotation)
                imageAnalyzer?.setTargetRotation(view.display.rotation)
            }
        } ?: Unit
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mainExecutor = ContextCompat.getMainExecutor(requireContext())
        analysisExecutor = Executors.newSingleThreadExecutor()
    }

    override fun onResume() {
        super.onResume()
        // Make sure that all permissions are still present, since the
        // user could have removed them while the app was in paused state.
        if (!PermissionsFragment.hasPermissions(requireContext())) {
            Navigation.findNavController(requireActivity(), R.id.nav_edit_host_fragment)
                .navigate(R.id.action_cameraPreviewFragment_to_permissionsFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // Unregister the broadcast receivers and listeners
        broadcastManager.unregisterReceiver(volumeDownReceiver)
        displayManager.unregisterDisplayListener(displayListener)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? =
        inflater.inflate(R.layout.fragment_camera_preview, container, false)


    /** Define callback that will be triggered after a photo has been taken and saved to disk */
    private val imageSavedListener = object : ImageCapture.OnImageSavedCallback {
        override fun onError(imageCaptureError: Int, message: String, cause: Throwable?) {
            Log.e(TAG, "Photo capture failed: $message", cause)
        }

        override fun onImageSaved(photoFile: File) {
            Log.d(TAG, "Photo capture succeeded: ${photoFile.absolutePath}")

            // If the folder selected is an external media directory, this is unnecessary
            // but otherwise other apps will not be able to access our images unless we
            // scan them using [MediaScannerConnection]
            val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(photoFile.extension)
            MediaScannerConnection.scanFile(
                context, arrayOf(photoFile.absolutePath), arrayOf(mimeType), null
            )
            val img = FirebaseVisionImage.fromFilePath(requireActivity(), photoFile.toUri())
            val detector = FirebaseVision.getInstance().onDeviceTextRecognizer
            detector.processImage(img).addOnSuccessListener { firebaseVisionText ->
                Snackbar.make(requireView(), firebaseVisionText.text, Snackbar.LENGTH_INDEFINITE).also {
                    it.setAction("X") { _ -> it.dismiss() }
                    it.show()
                }
            }
                .addOnFailureListener { exception -> Log.e(TAG, "onImageSaved: ML Failed", exception) }

        }
    }

    @SuppressLint("MissingPermission")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        container = view as FrameLayout
        viewFinder = container.findViewById(R.id.view_finder)
        broadcastManager = LocalBroadcastManager.getInstance(view.context)

        // Set up the intent filter that will receive events from our main activity
        val filter = IntentFilter().apply { addAction(KEY_EVENT_ACTION) }
        broadcastManager.registerReceiver(volumeDownReceiver, filter)

        // Every time the orientation of device changes, recompute layout
        displayManager = viewFinder.context
            .getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager.registerDisplayListener(displayListener, null)

        // Determine the output directory
        outputDirectory = MainActivity.getOutputDirectory(requireContext())

        // Wait for the views to be properly laid out
        viewFinder.post {

            // Keep track of the display in which this view is attached
            displayId = viewFinder.display.displayId

            // Build UI controls
            updateCameraUi()

            // Bind use cases
            bindCameraUseCases()
        }
    }

    /**
     * Inflate camera controls and update the UI manually upon config changes to avoid removing
     * and re-adding the view finder from the view hierarchy; this provides a seamless rotation
     * transition on devices that support it.
     *
     * NOTE: The flag is supported starting in Android 8 but there still is a small flash on the
     * screen for devices that run Android 9 or below.
     */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateCameraUi()
    }


    /** Declare and bind preview, capture and analysis use cases */
    @SuppressLint("RestrictedApi")
    private fun bindCameraUseCases() {

        // Get screen metrics used to setup camera for full screen resolution
        val metrics = DisplayMetrics().also { viewFinder.display.getRealMetrics(it) }
        Log.d(TAG, "Screen metrics: ${metrics.widthPixels} x ${metrics.heightPixels}")

        val screenAspectRatio = aspectRatio(metrics.widthPixels, metrics.heightPixels)
        Log.d(TAG, "Preview aspect ratio: $screenAspectRatio")

        val rotation = viewFinder.display.rotation

        // Bind the CameraProvider to the LifeCycleOwner
        val cameraSelector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        val cameraProviderFuture: ListenableFuture<ProcessCameraProvider> = ProcessCameraProvider.getInstance(requireContext())
        cameraProviderFuture.addListener(Runnable {

            // CameraProvider
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()

            // Preview
            preview = Preview.Builder()
                // We request aspect ratio but no resolution
                .setTargetAspectRatio(screenAspectRatio)
                // Set initial target rotation
                .setLensFacing(CameraSelector.LENS_FACING_BACK)
                .setTargetRotation(rotation)
                .build()
                .also {
                    it.previewSurfaceProvider = viewFinder.previewSurfaceProvider
                }

            if (outlineOverlay != null) {

                //TODO preview?.getAttachedSurfaceResolution(getIdForRequestedCamera(CameraSelector.LENS_FACING_BACK))
            }

            // Default PreviewSurfaceProvider


            // ImageCapture
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                // We request aspect ratio but no resolution to match preview config, but letting
                // CameraX optimize for whatever specific resolution best fits requested capture mode
                .setTargetAspectRatio(screenAspectRatio)
                // Set initial target rotation, we will have to call this again if rotation changes
                // during the lifecycle of this use case
                .setTargetRotation(rotation)
                .build()

            // ImageAnalysis
            imageAnalyzer = ImageAnalysis.Builder()
                // We request aspect ratio but no resolution
                .setTargetAspectRatio(screenAspectRatio)
                // Set initial target rotation, we will have to call this again if rotation changes
                // during the lifecycle of this use case
                .setTargetRotation(rotation)
                .build()
                // The analyzer can then be assigned to the instance
                .also { analysis ->
                    /*
                    it.setAnalyzer(analysisExecutor, LuminosityAnalyzer { luma ->
                        // Values returned from our analyzer are passed to the attached listener
                        // We log image analysis results here - you should do something useful instead!
                        Log.d(TAG, "Average luminosity: $luma")
                    })

                     */
                    analysis.setAnalyzer(
                        analysisExecutor,
                        TextImageAnalyzer(downloadingML = { e ->
                            Toast.makeText(requireActivity(), "Downloading Analyser!\nPlease Wait!", Toast.LENGTH_SHORT).show()
                        }) { text ->
                            println("text = ${text.text}")
                            if (outlineOverlay != null) {
                                outlineOverlay.clear()
                                val boxes = text.textBlocks.filter { box -> box.boundingBox != null }
                                boxes.forEach { block -> outlineOverlay.add(OutlineGraphic(outlineOverlay, block)) }
                                outlineOverlay.postInvalidate()
                            }
                        }
                    )
                }

            // Must unbind the use-cases before rebinding them.
            cameraProvider.unbindAll()

            try {
                // A variable number of use-cases can be passed here -
                // camera provides access to CameraControl & CameraInfo
                camera = cameraProvider.bindToLifecycle(
                    this as LifecycleOwner, cameraSelector, preview, imageCapture, imageAnalyzer
                )
            } catch (exc: Exception) {
                Log.e(TAG, "Use case binding failed", exc)
            }

        }, mainExecutor)
    }

    //Thesis Example
    fun processDate(potentialDateString: String, confidence: Float) {
        val editViewModel: EditViewModel by activityViewModels()
        try {
            val date = LocalDate.parse(potentialDateString)
            editViewModel.temporalEdit.date.setValue(
                Edit.PredictionBy.Camera(
                    value = date,
                    confidence = confidence
                )
            )
        } catch (e: DateTimeParseException) {
            /* Handle Parse Exception */
        }
    }

    /**
     *  [androidx.camera.core.ImageAnalysisConfig] requires enum value of
     *  [androidx.camera.core.AspectRatio]. Currently it has values of 4:3 & 16:9.
     *
     *  Detecting the most suitable ratio for dimensions provided in @params by counting absolute
     *  of preview ratio to one of the provided values.
     *
     *  @param width - preview width
     *  @param height - preview height
     *  @return suitable aspect ratio
     */
    private fun aspectRatio(width: Int, height: Int): Int {
        val previewRatio = max(width, height).toDouble() / min(width, height)
        if (abs(previewRatio - RATIO_4_3_VALUE) <= abs(previewRatio - RATIO_16_9_VALUE)) {
            return AspectRatio.RATIO_4_3
        }
        return AspectRatio.RATIO_16_9
    }

    /** Method used to re-draw the camera UI controls, called every time configuration changes. */
    private fun updateCameraUi() {

        // Remove previous UI if any
        container.findViewById<ConstraintLayout>(R.id.camera_ui_container)?.let {
            container.removeView(it)
        }

        // Inflate a new view containing all UI for controlling the camera
        val controls = View.inflate(requireContext(), R.layout.camera_ui_container, container)

        // Listener for button used to capture photo
        controls.findViewById<ImageButton>(R.id.camera_capture_button).setOnClickListener {

            // Get a stable reference of the modifiable image capture use case
            imageCapture?.let { imageCapture ->

                // Create output file to hold the image
                val photoFile = createFile(outputDirectory, FILENAME, PHOTO_EXTENSION)

                // Setup image capture metadata
                val metadata = Metadata().apply {

                    // Mirror image when using the front camera
                    isReversedHorizontal = lensFacing == CameraSelector.LENS_FACING_FRONT
                }

                // Setup image capture listener which is triggered after photo has been taken
                imageCapture.takePicture(photoFile, metadata, mainExecutor, imageSavedListener)

                // We can only change the foreground Drawable using API level 23+ API
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                    // Display flash animation to indicate that photo was captured
                    container.postDelayed({
                        container.foreground = ColorDrawable(Color.WHITE)
                        container.postDelayed(
                            { container.foreground = null }, ANIMATION_FAST_MILLIS
                        )
                    }, ANIMATION_SLOW_MILLIS)
                }
            }
        }

        // Listener for button used to switch cameras
        controls.findViewById<ImageButton>(R.id.camera_switch_button).setOnClickListener {
            lensFacing = if (CameraSelector.LENS_FACING_FRONT == lensFacing) {
                CameraSelector.LENS_FACING_BACK
            } else {
                CameraSelector.LENS_FACING_FRONT
            }
            // Bind use cases
            bindCameraUseCases()
        }

    }

    private class TextImageAnalyzer(private val downloadingML: MLDownloadingExceptionListener = {}, listener: TextPreviewListener? = null) :
        ImageAnalysis.Analyzer {

        var sizeListener: AnalysisSizeListener? = null
        private val listeners = ArrayList<TextPreviewListener>().apply { listener?.let { add(it) } }

        private var task: Task<FirebaseVisionText>? = null
        private var timeStartOverall: Long? = null
        private var timeStart: Long? = null
        private var timeLastImage: Long? = null
        private var timeBetween: MutableList<Long> = mutableListOf()
        private var timeBetweenAll: MutableList<Stat> = mutableListOf()
        private var imgCount = 0
        private var skipNr: Int = 0

        data class Stat(
            val timeStamp: Long, val analysisDuration: Long, val skippedImages: Int
        )

        private fun degreesToFirebaseRotation(degrees: Int): Int = when (degrees) {
            0 -> FirebaseVisionImageMetadata.ROTATION_0
            90 -> FirebaseVisionImageMetadata.ROTATION_90
            180 -> FirebaseVisionImageMetadata.ROTATION_180
            270 -> FirebaseVisionImageMetadata.ROTATION_270
            else -> throw Exception("Rotation must be 0, 90, 180, or 270.")
        }


        @ExperimentalGetImage
        override fun analyze(imageProxy: ImageProxy) {
            if (timeStartOverall == null) timeStartOverall = System.currentTimeMillis()
            val l = System.currentTimeMillis() - timeStartOverall!!
            if (l > 20 * 1000) {
                Log.d(
                    "TimingTracking",
                    "Summary:\n" +
                            " Total Images: $imgCount (FPS: ${imgCount / (l / 1000)})\n" +
                            " Total Analysed: ${timeBetweenAll.size}\n" +
                            " Analysis Duration AVG: ${timeBetweenAll.sumBy { it.analysisDuration.toInt() }.div(timeBetweenAll.size)}\n" +
                            " AVG Images Skipped per Analysis: ${timeBetweenAll.sumBy { it.skippedImages }.div(timeBetweenAll.size)}"
                )
                timeStartOverall = null
                imgCount = 0
            }
            imgCount++
            val timeSinceImage = System.currentTimeMillis() - (timeLastImage ?: System.currentTimeMillis())
            timeLastImage = System.currentTimeMillis()
            if ((task != null && !task!!.isComplete) || listeners.isEmpty()) {
                skipNr++
                timeBetween.add(timeSinceImage)
                imageProxy.close()
                return
            } else {
                timeBetweenAll.add(Stat(timeSinceImage, timeBetween.sum(), skipNr))
                if (timeBetween.size > 0) {
                    Log.d(
                        "TimingTracking",
                        "Image analyzes started - Time Since Last = ${timeBetween.sum()} ms - Skipped Images: $skipNr (AVG: ${timeBetween.sum()
                            .div(timeBetween.size)} ms)"
                    )
                } else {
                    Log.d(
                        "TimingTracking",
                        "Image analyzes started - Time Since Last = ${timeBetween.sum()} ms - Skipped Images: $skipNr (AVG: NAN)"
                    )
                }
                skipNr = 0
                timeBetween = mutableListOf()
            }

            sizeListener?.invoke(Size(imageProxy.width, imageProxy.height))

            val mediaImage = imageProxy.image
            val rotationDegrees = imageProxy.imageInfo.rotationDegrees
            val imageRotation = degreesToFirebaseRotation(rotationDegrees)
            timeStart = System.currentTimeMillis()
            if (mediaImage != null) {
                val image = FirebaseVisionImage.fromMediaImage(mediaImage, imageRotation)
                val detector = FirebaseVision.getInstance().onDeviceTextRecognizer
                task = detector.processImage(image)
                    .addOnSuccessListener { firebaseVisionText ->
                        //Log.d("TimingTracking", "Analyzer finished task - ${System.currentTimeMillis() - timeStart!!} ms elapsed")
                        listeners.forEach { it(firebaseVisionText) }
                        Log.d(TAG, "analyze: Success ML")
                    }
                    .addOnFailureListener { e ->
                        Log.d(TAG, "analyze: Fail ML")
                        if (e is FirebaseMLException && e.code == FirebaseMLException.UNAVAILABLE) {
                            downloadingML(e)
                        } else {
                            throw e
                        }
                    }

            }
            imageProxy.close()

        }

    }


    /**
     * Our custom image analysis class.
     *
     * <p>All we need to do is override the function `analyze` with our desired operations. Here,
     * we compute the average luminosity of the image by looking at the Y plane of the YUV frame.
     */
    private class LuminosityAnalyzer(listener: LumaListener? = null) : ImageAnalysis.Analyzer {
        private val frameRateWindow = 8
        private val frameTimestamps = ArrayDeque<Long>(5)
        private val listeners = ArrayList<LumaListener>().apply { listener?.let { add(it) } }
        private var lastAnalyzedTimestamp = 0L
        var framesPerSecond: Double = -1.0
            private set

        /**
         * Used to add listeners that will be called with each luma computed
         */
        fun onFrameAnalyzed(listener: LumaListener) = listeners.add(listener)

        /**
         * Helper extension function used to extract a byte array from an image plane buffer
         */
        private fun ByteBuffer.toByteArray(): ByteArray {
            rewind()    // Rewind the buffer to zero
            val data = ByteArray(remaining())
            get(data)   // Copy the buffer into a byte array
            return data // Return the byte array
        }

        /**
         * Analyzes an image to produce a result.
         *
         * <p>The caller is responsible for ensuring this analysis method can be executed quickly
         * enough to prevent stalls in the image acquisition pipeline. Otherwise, newly available
         * images will not be acquired and analyzed.
         *
         * <p>The image passed to this method becomes invalid after this method returns. The caller
         * should not store external references to this image, as these references will become
         * invalid.
         *
         * @param image image being analyzed VERY IMPORTANT: Analyzer method implementation must
         * call image.close() on received images when finished using them. Otherwise, new images
         * may not be received or the camera may stall, depending on back pressure setting.
         *
         */
        override fun analyze(image: ImageProxy) {
            // If there are no listeners attached, we don't need to perform analysis
            if (listeners.isEmpty()) {
                image.close()
                return
            }

            // Keep track of frames analyzed
            val currentTime = System.currentTimeMillis()
            frameTimestamps.push(currentTime)

            // Compute the FPS using a moving average
            while (frameTimestamps.size >= frameRateWindow) frameTimestamps.removeLast()
            val timestampFirst = frameTimestamps.peekFirst() ?: currentTime
            val timestampLast = frameTimestamps.peekLast() ?: currentTime
            framesPerSecond = 1.0 / ((timestampFirst - timestampLast) /
                    frameTimestamps.size.coerceAtLeast(1).toDouble()) * 1000.0

            // Analysis could take an arbitrarily long amount of time
            // Since we are running in a different thread, it won't stall other use cases

            lastAnalyzedTimestamp = frameTimestamps.first

            // Since format in ImageAnalysis is YUV, image.planes[0] contains the luminance plane
            val buffer = image.planes[0].buffer

            // Extract image data from callback object
            val data = buffer.toByteArray()

            // Convert the data into an array of pixel values ranging 0-255
            val pixels = data.map { it.toInt() and 0xFF }

            // Compute average luminance for the image
            val luma = pixels.average()

            // Call all listeners with new value
            listeners.forEach { it(luma) }

            image.close()
        }
    }

    companion object {

        private const val TAG = "CameraXBasic"
        private const val FILENAME = "yyyy-MM-dd-HH-mm-ss-SSS"
        private const val PHOTO_EXTENSION = ".jpg"
        private const val RATIO_4_3_VALUE = 4.0 / 3.0
        private const val RATIO_16_9_VALUE = 16.0 / 9.0

        /** Helper function used to create a timestamped file */
        private fun createFile(baseFolder: File, format: String, extension: String) =
            File(
                baseFolder, SimpleDateFormat(format, Locale.US)
                    .format(System.currentTimeMillis()) + extension
            )
    }

}


/*
lateinit var navController: NavController

private lateinit var container: ConstraintLayout
private lateinit var viewFinder: PreviewView
private lateinit var outputDirectory: File
private lateinit var broadcastManager: LocalBroadcastManager
private lateinit var displayManager: DisplayManager
private lateinit var mainExecutor: Executor
private lateinit var analysisExecutor: Executor

private var displayId: Int = -1
private var lensFacing: Int = CameraSelector.LENS_FACING_BACK
private var preview: Preview? = null
private var imageCapture: ImageCapture? = null
private var imageAnalyzer: ImageAnalysis? = null
private var camera: Camera? = null


override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
}

override fun onCreateView(
    inflater: LayoutInflater, container: ViewGroup?,
    savedInstanceState: Bundle?
): View? {
    return inflater.inflate(R.layout.fragment_camera_preview, container, false)
}

override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
    super.onViewCreated(view, savedInstanceState)
    navController = Navigation.findNavController(view)

    viewFinder = view.findViewById(R.id.view_finder)

    if (allPermissionsGranted()) {
        viewFinder.post { startCamera() }
    } else {
        requestPermissions(REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)
    }

    viewFinder.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
        updateTransform()
    }
}


private val executor = Executors.newSingleThreadExecutor()
private lateinit var viewFinder: TextureView

private fun startCamera() {
    //cameraProviderFuture = ProcessCameraProvider.getInstance(activity!!)
    val preview = Preview.Builder().apply {
        setTargetResolution(Size(640, 480))
    }.build()
    cameraProviderFuture.addListener(Runnable {
       val cameraProvider = cameraProviderFuture.get()
        bindPreview(cameraProvider)
    }, ContextCompat.getMainExecutor(activity!!))

}

fun bindPreview(cameraProvider : ProcessCameraProvider) {
    var preview : Preview = Preview.Builder()
        .setTargetName("Preview")
        .build()


    preview.setPreviewSurfaceProvider { resolution, surfaceReleaseFuture ->
        // Create the SurfaceTexture with the required resolution
        val surfaceTexture = SurfaceTexture(0)
        surfaceTexture.setDefaultBufferSize(resolution.width, resolution.height)
        val surface = Surface(surfaceTexture)

        // Once surfaceReleaseFuture completes, the Surface and SurfaceTexture
        // are no longer used by the camera hence safe to close.
        surfaceReleaseFuture.addListener(
            Runnable {
                surface.release()
                surfaceTexture.release()
            }, ContextCompat.getMainExecutor(activity!!))

        // Return the Surface back in a ListenableFuture
        Futures.immediateFuture(surface)
    }


    var cameraSelector : CameraSelector = CameraSelector.Builder()
        .requireLensFacing(CameraSelector.LENS_FACING_BACK)
        .build()

    cameraProvider.bindToLifecycle(this, cameraSelector, preview)
}

private fun updateTransform() {
    // TO!DO: Implement camera viewfinder transformations
}






/**
 * Process result from permission request dialog box, has the request
 * been granted? If yes, start Camera. Otherwise display a toast
 */
override fun onRequestPermissionsResult(
    requestCode: Int, permissions: Array<String>, grantResults: IntArray
) {
    if (requestCode == REQUEST_CODE_PERMISSIONS) {
        if (allPermissionsGranted()) {
            viewFinder.post { startCamera() }
        } else {
            Toast.makeText(activity!!, "Permissions not granted by the user.", Toast.LENGTH_SHORT).show()
            navController.navigateUp()
        }
    }
}

/**
 * Check if all permission specified in the manifest have been granted
 */
private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
    ContextCompat.checkSelfPermission(activity!!.baseContext, it) == PackageManager.PERMISSION_GRANTED
}

}

 */