package com.github.jan222ik.divelogbook.predictions.sensors

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.util.CoordinateCalculations
import com.google.android.gms.location.*

abstract class GPSBaseFragment : Fragment() {

    private val PERMISSION_ID = 42
    lateinit var locationClient: FusedLocationProviderClient

    fun init() {
        locationClient = LocationServices.getFusedLocationProviderClient(requireActivity())
        getLastLocation()
    }

    @SuppressLint("MissingPermission")
    private fun getLastLocation() {
        if (!hasLocationPermissions()) {
            requestPermissions()
        } else { // Has Permission
            if (isLocationEnabled()) {
                locationClient.lastLocation
                    .addOnCompleteListener(requireActivity()) { task ->
                        val location: Location? = task.result
                        if (location == null) {
                            requestNewLocationData()
                        } else {
                            updateLocationDependants(location)
                        }
                    }
            } else {
                showEnableGPSDialog()
            }
        }
    }

    abstract fun updateLocationDependants(location: Location)

    fun showEnableGPSDialog() {
        Toast.makeText(requireContext(), "Turn on location", Toast.LENGTH_LONG).show()
        val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        startActivity(intent)
    }

    @SuppressLint("MissingPermission")
    private fun requestNewLocationData() {
        val request = LocationRequest()
        request.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        request.interval = 0
        request.fastestInterval = 0
        request.numUpdates = 1

        locationClient = LocationServices.getFusedLocationProviderClient(requireActivity())
        locationClient.requestLocationUpdates(
            request, locationCallback,
            Looper.myLooper()
        )
    }

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult) {
            val lastLocation: Location = locationResult.lastLocation
            updateLocationDependants(lastLocation)
        }
    }

    private fun isLocationEnabled(): Boolean {
        val locationManager: LocationManager = requireActivity().getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
            LocationManager.NETWORK_PROVIDER
        )
    }

    private fun hasLocationPermissions(): Boolean =
        hasPermissionFor(Manifest.permission.ACCESS_COARSE_LOCATION) && hasPermissionFor(Manifest.permission.ACCESS_FINE_LOCATION)


    private fun requestPermissions() {
        ActivityCompat.requestPermissions(
            requireActivity(),
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION),
            PERMISSION_ID
        )
    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_ID) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                getLastLocation()
            }
        }
    }

    private fun hasPermissionFor(s: String) = ActivityCompat.checkSelfPermission(requireContext(), s) == PackageManager.PERMISSION_GRANTED


}

class GPSFrag : GPSBaseFragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val inflate = inflater.inflate(R.layout.gps_test, container, false)
        init()
        return inflate
    }

    override fun updateLocationDependants(location: Location) {
        requireActivity().findViewById<TextView>(R.id.latTextView).text = location.latitude.toString()
        requireActivity().findViewById<TextView>(R.id.lonTextView).text = location.longitude.toString()
        Toast.makeText(
            requireContext(),
            CoordinateCalculations.metersDistanceBetweenLocations(0.0, 0.0, location.latitude, location.longitude)?.div(1000)
                .toString(),
            Toast.LENGTH_LONG
        ).show()
    }
}