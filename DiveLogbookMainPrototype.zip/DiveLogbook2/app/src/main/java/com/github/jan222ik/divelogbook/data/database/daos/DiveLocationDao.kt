package com.github.jan222ik.divelogbook.data.database.daos

import androidx.lifecycle.LiveData
import androidx.paging.DataSource
import androidx.paging.PagedList
import androidx.room.*
import androidx.sqlite.db.SimpleSQLiteQuery
import androidx.sqlite.db.SupportSQLiteQuery
import com.github.jan222ik.divelogbook.data.database.entities.DiveLocationEntity
import com.github.jan222ik.divelogbook.data.database.pojos.DiveLocation
import com.github.jan222ik.divelogbook.ui.viewmodel.LocationViewModel

@Dao
abstract class DiveLocationDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    abstract suspend fun insert(diveLocationEntity: DiveLocationEntity): Long

    @Update
    abstract suspend fun update(diveLocationEntity: DiveLocationEntity)

    @Query("DELETE FROM DiveLocationEntity")
    abstract suspend fun deleteAll()

    @Query("Select * FROM DiveLocationEntity Where locationId = :locationId")
    abstract suspend fun getById(locationId: Long): DiveLocationEntity

    @Transaction
    @Query("Select * FROM DiveLocationEntity Where locationId = :locationId")
    abstract suspend fun getPojoById(locationId: Long): DiveLocation

    @Transaction
    @Query("Select * FROM DiveLocationEntity Where locationId = :locationId")
    abstract fun getLivePojoById(locationId: Long): LiveData<DiveLocation?>

    @Query("Select * FROM DiveLocationEntity")
    abstract fun getAllPaged(): DataSource.Factory<Int, DiveLocation>

    @Query("Select Distinct country From AddressEntity")
    abstract fun getAllUsedCountries(): List<String>

    @RawQuery(observedEntities = [DiveLocation::class])
    internal abstract fun getPagedByFilterQuery(rawQuery: SupportSQLiteQuery): DataSource.Factory<Int, DiveLocation>

    //@Query("Select * From DiveLocationEntity as w INNER JOIN DiveSpotEntity as spot On spot.spotId = w.spotEntityId Where spotName LIKE ?")
    //abstract fun test()

    fun getPagedByFilter(input: LocationViewModel.LocationFilter): DataSource.Factory<Int, DiveLocation> {
        val query = "Select * From DiveLocationEntity as w INNER JOIN DiveSpotEntity as spot On spot.spotId = w.spotEntityId Where spotName LIKE ?"
        return getPagedByFilterQuery(SimpleSQLiteQuery(query, arrayOf("%${input.mixedString}%")))
    }

    @Query("Select * From DiveLocationEntity")
    abstract fun getAll(): LiveData<List<DiveLocation>>?
}