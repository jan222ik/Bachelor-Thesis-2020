package com.github.jan222ik.divelogbook.ui.viewmodel

val numberRange = "(?<start>[0-9]*)(-?)(?<end>[0-9]*)".toRegex()

class SearchEvaluator {

    private val _filter = Filter()
    val filter: Filter
        get() = build()


    fun addGeneralInputString(input: String) {
        addDiveNumberRangeInput(input)
        if (input != "") {
            _filter.general = input
            _filter.country = input
        }
    }

    fun addDiveNumberRangeInput(rangeString: String) {
        if (rangeString != "") {
            val result = numberRange.find(rangeString)
            if (result != null) {
                val (start, isRange, end) = result.destructured
                _filter.numberStart = start.toIntOrNull()
                _filter.numberEnd = end.toIntOrNull()
                if (isRange.isEmpty()) {
                    _filter.numberEnd = start.toIntOrNull()
                }
            }
        }
    }

    fun changeMode(isAnd: Boolean = !_filter.isAndMode): Boolean {
        _filter.isAndMode = isAnd
        return _filter.isAndMode
    }

    fun build(): Filter {
        return _filter.copy()
    }

}