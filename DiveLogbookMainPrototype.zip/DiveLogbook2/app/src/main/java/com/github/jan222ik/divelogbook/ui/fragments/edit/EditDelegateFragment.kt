package com.github.jan222ik.divelogbook.ui.fragments.edit

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.ui.viewmodel.EditViewModel


class EditDelegateFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val model: EditViewModel by activityViewModels()
        val navController = Navigation.findNavController(requireActivity(), R.id.nav_edit_host_fragment)
        if (model.isNew()) {
            navController.navigate(R.id.action_editDelegateFragment_to_editMainFragment)
        } else {
            navController.navigate(R.id.action_editDelegateFragment_to_editOptionsExistingFragment)
        }
    }

}