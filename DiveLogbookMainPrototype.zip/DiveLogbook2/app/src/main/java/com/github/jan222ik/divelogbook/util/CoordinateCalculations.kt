package com.github.jan222ik.divelogbook.util

import java.util.*
import kotlin.math.*

object CoordinateCalculations {
    fun metersDistanceBetweenLocations(latA: Double?, lonA: Double?, latB: Double?, lonB: Double?): Double? {
        if (latA == null || lonA == null || latB == null || lonB == null) return null
        // Haversine Formula
        val r = 6371e3 //Earth Mean Radius in Meter
        val phi1 = radians(latA)
        val phi2 = radians(latB)
        val deltaPhi = radians(latB - latA)
        val deltaLambda = radians(lonB - lonA)

        val a = sin(deltaPhi / 2).pow(2) + cos(phi1) * cos(phi2) * sin(deltaLambda / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a));

        return r * c
    }

    private fun radians(x: Double) : Double = x * Math.PI / 180
}