package com.github.jan222ik.divelogbook.ui.fragments.read.locationlist

import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ArrayAdapter
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.blongho.country_data.World
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.database.pojos.DiveLocation
import com.github.jan222ik.divelogbook.ui.viewmodel.Filter
import com.github.jan222ik.divelogbook.ui.viewmodel.LogbookViewModel
import kotlinx.android.synthetic.main.filter_spot.*
import kotlinx.android.synthetic.main.fragment_dive_pagedlist_list.view.*

class LocationPagedListFragment : Fragment(),
    LocationListPagedAdapter.LocationListPagedAdapterClickActions {

    private lateinit var navController: NavController

    private var model: LogbookViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        World.init(requireActivity())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        val view = inflater.inflate(R.layout.fragment_location_pagedlist_list, container, false)
        model = ViewModelProviders.of(requireActivity()).get(LogbookViewModel::class.java)

        with(view.list as RecyclerView) {
            layoutManager = LinearLayoutManager(context)
            val realAdapter =
                LocationListPagedAdapter(
                    this@LocationPagedListFragment
                )
            adapter = realAdapter

            model!!.initLocation()
            model!!.allLocations!!.observe(requireActivity(), Observer {
                Log.d("TAG", "onCreateView: Data refresh")
                realAdapter.submitList(it)
            })
            model!!.applyLocationFilter()
        }
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        navController = Navigation.findNavController(view)
        with(view.fab) {
            setOnClickListener {
                model!!.setEdit(null)
                navController.navigate(R.id.action_locationPagedListFragment_to_editSpotFragment)
            }
        }
        with(view.filterByGPSBtn) {
            setOnClickListener { showFilterDialog() }
        }
    }

    override fun onClickLocation(item: DiveLocation) {
        model!!.setDetailLocation(item)
        navController.navigate(R.id.action_locationPagedListFragment_to_locationDetailFragment)
    }

    private fun showFilterDialog() {
        val dialog = Dialog(requireActivity(), android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.filter_spot)
        val allUsedCountries = model!!.getAllUsedCountries()
        dialog.selectCountry.setAdapter(ArrayAdapter<String>(requireActivity(), android.R.layout.simple_dropdown_item_1line, allUsedCountries))

        dialog.applyButton.setOnClickListener {
            val textString = dialog.selectCountry.textString
            if (textString.isNotEmpty()) {
                model!!.updateFilter(
                    Filter(
                        numberStart = textString.toInt()
                    )
                )
            }
            dialog.dismiss()
        }
        dialog.show()
    }

    private var EditText.textString
        get() = this.text.toString()
        set(value) = this.setText(value)

}
