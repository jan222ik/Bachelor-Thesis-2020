package com.github.jan222ik.divelogbook.ui.fragments.read.locationlist

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.paging.PagedListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.blongho.country_data.World
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.database.pojos.DiveLocation
import kotlinx.android.synthetic.main.locationlist_item.view.*
import java.util.function.Consumer

class LocationListPagedAdapter(private val onItemClick: LocationListPagedAdapterClickActions) :
    PagedListAdapter<DiveLocation, LocationListPagedAdapter.ViewHolder>(
        DiffUtilCallBack()
    ) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.locationlist_item, parent, false)
        return ViewHolder(
            view,
            onItemClick
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        getItem(position)?.let { holder.bindPost(it) }
    }


    class ViewHolder(
        itemView: View,
        private val onItemClick: LocationListPagedAdapterClickActions
    ) :
        RecyclerView.ViewHolder(itemView),
        View.OnClickListener {

        private lateinit var diveLocation: DiveLocation
        private var expandedChangeListener: Consumer<Boolean>? = null

        fun bindPost(it: DiveLocation) {
            itemView.show_more.rotation = 180F
            //itemView.extraInfo.visibility = View.GONE
            diveLocation = it
            with(itemView) {
                val country = diveLocation.address?.country
                if (country != null) {
                    countryImg.setImageResource(World.getFlagOf(country))
                    countryImg.visibility = View.VISIBLE
                } else {
                    countryImg.visibility = View.GONE
                }
                spotname.text = diveLocation.spot.spotName
            }
        }

        init {
            with(itemView) {
                itemView.setOnClickListener(this@ViewHolder)
                show_more.rotation = 180F
                show_more.setOnClickListener { v: View? ->
                    if (v != null) {
                        if (v.rotation == 180F) {
                            //extraInfo.visibility = View.VISIBLE
                            expandedChangeListener?.accept(true)
                            v.rotation = 0F
                        } else {
                            //extraInfo.visibility = View.GONE
                            expandedChangeListener?.accept(false)
                            v.rotation = 180F
                        }
                    }
                }
            }
        }

        override fun onClick(v: View?) {
            onItemClick.onClickLocation(diveLocation)
        }

    }

    interface LocationListPagedAdapterClickActions {
        fun onClickLocation(item: DiveLocation)
    }

    class DiffUtilCallBack : DiffUtil.ItemCallback<DiveLocation>() {
        override fun areItemsTheSame(oldItem: DiveLocation, newItem: DiveLocation): Boolean {
            return oldItem.entity.locationId == newItem.entity.locationId
        }

        override fun areContentsTheSame(oldItem: DiveLocation, newItem: DiveLocation): Boolean {
            return oldItem == newItem
        }

    }
}