package com.github.jan222ik.divelogbook.ui.fragments.read.appliers

import android.view.View
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.database.pojos.DiveLocation
import kotlinx.android.synthetic.main.detail_dive_location.view.*

object DiveLocationApplier : DetailApplier<DiveLocation?> {

    override fun apply(view: View, data: DiveLocation?, hideEmpty: Boolean): Boolean {
        with(view) {
            var vis = false
            val missing = lazy { resources.getString(R.string.missingData) }
            locationSpot.text = data?.spot?.spotName.also { vis = vis and it.visibilityFor(listOf(locationSpot, spotLabel), hideEmpty) } ?: missing.value
            locationBodyWater.text =
                data?.spot?.bodyOfWater.also { vis = vis and it.visibilityFor(listOf(locationBodyWater, bodyWaterLabel), hideEmpty) } ?: missing.value

            val alt = data?.spot?.altitude
            vis = vis and alt.visibilityFor(listOf(locationAltitude, altitudeLabel), hideEmpty)
            locationAltitude.text = alt?.toString() ?: missing.value

            val longitude = data?.spot?.longitude
            vis = vis and longitude.visibilityFor(listOf(locationLongitude, longitudeLabel), hideEmpty)
            locationLongitude.text = longitude?.toString() ?: missing.value

            val latitude = data?.spot?.latitude
            vis = vis and latitude.visibilityFor(listOf(locationLatitude, latitudeLabel), hideEmpty)
            locationLatitude.text = latitude?.toString() ?: missing.value
            return vis
        }
    }
}