package com.github.jan222ik.divelogbook.data.database.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(tableName = "logbookDive")
data class LogbookDiveEntity(
    @ColumnInfo(name = "diveNumber")
    var diveNumber: Int,
    @ForeignKey(entity = DiveEntity::class, parentColumns = ["diveId"], childColumns = ["diveId"] )
    @ColumnInfo(name = "diveId")
    var diveId: Long? = null
) {
    @PrimaryKey(autoGenerate = true)
    var logbookDiveId: Int? = null
}