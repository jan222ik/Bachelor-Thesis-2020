package com.github.jan222ik.divelogbook.ui.fragments.edit.camera.experiment

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.DrawableRes
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.github.doyaaaaaken.kotlincsv.dsl.csvWriter
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.ui.fragments.edit.camera.experiment.experiments.*
import kotlinx.android.synthetic.main.fragment_experiment_base.view.*
import kotlinx.coroutines.launch
import org.opencv.android.OpenCVLoader


class ExperimentBaseFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_experiment_base, container, false)
        if (!OpenCVLoader.initDebug()) {
            Log.e("OpenCv", "Unable to load OpenCV")
        } else {
            Log.d("OpenCv", "OpenCV loaded")
        }
        lifecycleScope.launch {
           //old()
            val repitition = 1
            val experimentRaw = ExperimentRaw(repitition)
            view.textFromPicture.text = experimentRaw.joinToString(separator = "\n") { it.toString() }
            writeToCSV("raw", experimentRaw)

            val experimentGaussian = ExperimentThresholdGaussian(repitition)
            writeToCSV("gaussian", experimentGaussian)

            val experimentOzu = ExperimentThresholdOtsu(repitition)
            writeToCSV("otzu", experimentOzu)
        }
        return view
    }

    suspend fun ExperimentRaw(repitition: Int = 1): List<ExperimentStats> {
        val rawExperiment = RawExperiment(requireContext())
        val results = mutableListOf<List<ExperimentData>>()
        val textAndImages = arrayOf(
            ComparisonText.Words20Ipsum() to R.drawable.text_20_words_ipsum,
            ComparisonText.MetricDateWritten() to R.drawable.date_handwritten,
            ComparisonText.ThreeMetrics() to R.drawable.three_metrics
        )
        for ((text, imageId) in textAndImages) {
            results.add(
                rawExperiment.startExperiment(
                    name = text.name + "-Raw",
                    repetitions = repitition,
                    comparisonText = text,
                    image = getBitmapOfResources(imageId)!!
                )
            )
        }
        return results.map { experimentPerText ->
            var sumLevenshtein = 0
            experimentPerText.forEach {
                val diffMatchPatch = diff_match_patch()
                val diffs = diffMatchPatch.diff_main(it.comparisonText.text, it.textString)
                val diffLevenshtein = diffMatchPatch.diff_levenshtein(diffs)
                it.levenshteinDistance = diffLevenshtein
                sumLevenshtein += diffLevenshtein
            }
            ExperimentStats("Raw", experimentPerText, sumLevenshtein)
        }
    }

    suspend fun ExperimentThresholdGaussian(repitition: Int = 1): List<ExperimentStats> {
        val filterExperiment = ThresholdGaussianExperiment(requireContext())
        val results = mutableListOf<List<ExperimentData>>()
        val textAndImages = arrayOf(
            ComparisonText.Words20Ipsum() to R.drawable.text_20_words_ipsum,
            ComparisonText.MetricDateWritten() to R.drawable.date_handwritten,
            ComparisonText.ThreeMetrics() to R.drawable.three_metrics
        )
        for ((text, imageId) in textAndImages) {
            results.add(
                filterExperiment.startExperiment(
                    name = text.name + "-Gaussian",
                    repetitions = repitition,
                    comparisonText = text,
                    image = getBitmapOfResources(imageId)!!
                )
            )
        }
        return results.map { experimentPerText ->
            var sumLevenshtein = 0
            experimentPerText.forEach {
                val diffMatchPatch = diff_match_patch()
                val diffs = diffMatchPatch.diff_main(it.comparisonText.text, it.textString)
                val diffLevenshtein = diffMatchPatch.diff_levenshtein(diffs)
                it.levenshteinDistance = diffLevenshtein
                sumLevenshtein += diffLevenshtein
            }
            ExperimentStats("Gaussian", experimentPerText, sumLevenshtein)
        }
    }


    suspend fun ExperimentThresholdOtsu(repitition: Int = 1): List<ExperimentStats> {
        val filterExperiment = ThresholdOtsuExperiment(requireContext())
        val results = mutableListOf<List<ExperimentData>>()
        val textAndImages = arrayOf(
            ComparisonText.Words20Ipsum() to R.drawable.text_20_words_ipsum,
            ComparisonText.MetricDateWritten() to R.drawable.date_handwritten,
            ComparisonText.ThreeMetrics() to R.drawable.three_metrics
        )
        for ((text, imageId) in textAndImages) {
            results.add(
                filterExperiment.startExperiment(
                    name = text.name + "-Otsu",
                    repetitions = repitition,
                    comparisonText = text,
                    image = getBitmapOfResources(imageId)!!
                )
            )
        }
        return results.map { experimentPerText ->
            var sumLevenshtein = 0
            experimentPerText.forEach {
                val diffMatchPatch = diff_match_patch()
                val diffs = diffMatchPatch.diff_main(it.comparisonText.text, it.textString)
                val diffLevenshtein = diffMatchPatch.diff_levenshtein(diffs)
                it.levenshteinDistance = diffLevenshtein
                sumLevenshtein += diffLevenshtein
            }
            ExperimentStats("Otsu", experimentPerText, sumLevenshtein)
        }
    }

    data class ExperimentStats(val mehtodName: String, val data: List<ExperimentData>, val sumLevenshtein: Int) {
        fun size() = data.size
        fun mean() = sumLevenshtein.div(size())
        fun min() = data.minBy { it.levenshteinDistance ?: Int.MAX_VALUE }
        fun max() = data.maxBy { it.levenshteinDistance ?: Int.MIN_VALUE }

        override fun toString(): String {
            return "ExperimentStats(data=$data, sumLevenshtein=$sumLevenshtein, mean=${mean()}, min=${min()?.levenshteinDistance}, max=${max()?.levenshteinDistance}"
        }


    }

    fun old() {
        /*
           val rawExperiment = FiltersExperiment(requireContext())

           val experimentResult = rawExperiment.startExperiment(
               name = "Test",
               repetitions = 1,
               comparisonText = ComparisonText.Words20Ipsum(),
               image = getBitmapOfResources(R.drawable.text_20_words_ipsum)!!
           )
           Toast.makeText(requireContext(), "Results: ${experimentResult.size}", Toast.LENGTH_SHORT).show()
           val map = experimentResult.mapIndexed { ix, it ->
               val diffMatchPatch = diff_match_patch()
               val diffs = diffMatchPatch.diff_main(it.comparisonText.text, it.textString)
               val startString = "Text No: $ix\n"
               val spannable = SpannableStringBuilder(startString)
               var index = startString.lastIndex
               for (diff in diffs) {
                   val col = when (diff.operation) {
                       diff_match_patch.Operation.DELETE -> Color.Red
                       diff_match_patch.Operation.INSERT -> Color.Green
                       diff_match_patch.Operation.EQUAL -> Color.White
                       null -> Color.Blue
                   }
                   val currentIndex = index
                   index += diff.text.length
                   spannable
                       .append(diff.text)
                       .setSpan(
                           ForegroundColorSpan(col.toArgb()),
                           currentIndex + 1, index,
                           Spannable.SPAN_INCLUSIVE_INCLUSIVE
                       )
               }
               Snackbar.make(
                   view,
                   diff_match_patch().diff_levenshtein(diff_match_patch().diff_main("foo", "foobar")).toString(),
                   Snackbar.LENGTH_LONG
               ).show()
               //view.webView.
               return@mapIndexed spannable
           }
           view.texts.text = map[0]
           view.textFromPicture.text = experimentResult[0].textString
            */
    }

    fun writeToCSV(name: String, data: List<ExperimentStats>) {
        csvWriter().open(requireContext().openFileOutput("$name.csv", Context.MODE_PRIVATE)) {
            writeRow(listOf("Stats overall"))
            writeRow(listOf("Method", "Sum", "Mean", "Min", "Max"))
            for(item in data) {
                writeRow(listOf(item.mehtodName, item.sumLevenshtein, item.mean(), item.min()?.levenshteinDistance, item.max()?.levenshteinDistance))
            }
            writeRow(listOf("Data Overview"))
            for(item in data) {
                writeRow(listOf("Method:", item.mehtodName))
                writeRow(listOf("Name", "levenshteinDistance", "Repitition", "TextName", "timeAnalyser", "timePreProcessing", "text"))
                for(it in item.data) {
                    writeRow(listOf(it.name, it.levenshteinDistance, it.repetition, it.comparisonText.name, it.timeMillisAnalyser, it.timeMillisPreprocessing, it.textString))
                }
            }

        }
    }

    fun getBitmapOfResources(@DrawableRes id: Int): Bitmap? {
        val d = requireActivity().resources.getDrawable(id, null)
        val currentState = d.current
        return if (currentState is BitmapDrawable) currentState.bitmap else null
    }


}