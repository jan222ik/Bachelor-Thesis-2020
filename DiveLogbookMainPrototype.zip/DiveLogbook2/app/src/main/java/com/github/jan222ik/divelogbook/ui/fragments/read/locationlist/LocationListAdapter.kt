package com.github.jan222ik.divelogbook.ui.fragments.read.locationlist

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.blongho.country_data.World
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.database.pojos.DiveLocation
import com.github.jan222ik.divelogbook.util.CoordinateCalculations
import kotlinx.android.synthetic.main.locationlist_item.view.*
import java.util.function.Consumer

class LocationListAdapter(private val onItemClick: LocationListAdapterClickActions) :
    ListAdapter<LocationListAdapter.DiveLocationWrapper, LocationListAdapter.ViewHolder>(
        DiffUtilCallBack()
    ) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.locationlist_item, parent, false)
        return ViewHolder(
            view,
            onItemClick
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        getItem(position)?.let { holder.bindPost(it) }
    }


    class ViewHolder(
        itemView: View,
        private val onItemClick: LocationListAdapterClickActions
    ) :
        RecyclerView.ViewHolder(itemView),
        View.OnClickListener {

        private lateinit var diveLocationWrapper: DiveLocationWrapper

        fun bindPost(it: DiveLocationWrapper) {
            diveLocationWrapper = it
            val dist = diveLocationWrapper.distance?.div(1000)
            itemView.show_more.text = dist?.toString()?.plus("km") ?: ""
            with(itemView) {
                val country = diveLocationWrapper.diveLocation.address?.country
                if (country != null) {
                    countryImg.setImageResource(World.getFlagOf(country))
                    countryImg.visibility = View.VISIBLE
                } else {
                    countryImg.visibility = View.GONE
                }
                spotname.text = diveLocationWrapper.diveLocation.spot.spotName
            }
        }

        init {
            with(itemView) {
                itemView.setOnClickListener(this@ViewHolder)
            }
        }

        override fun onClick(v: View?) {
            onItemClick.onClickLocation(diveLocationWrapper.diveLocation)
        }

    }

    interface LocationListAdapterClickActions {
        fun onClickLocation(item: DiveLocation)
    }

    class DiffUtilCallBack : DiffUtil.ItemCallback<DiveLocationWrapper>() {
        override fun areItemsTheSame(oldItem: DiveLocationWrapper, newItem: DiveLocationWrapper): Boolean {
            return oldItem.diveLocation.entity.locationId == newItem.diveLocation.entity.locationId
        }

        override fun areContentsTheSame(oldItem: DiveLocationWrapper, newItem: DiveLocationWrapper): Boolean {
            return oldItem.diveLocation == newItem.diveLocation
        }

    }

    class DiveLocationWrapper(val diveLocation: DiveLocation, latCurrent: Double?, lonCurrent:Double?) {
        val distance = CoordinateCalculations.metersDistanceBetweenLocations(diveLocation.spot.latitude, diveLocation.spot.longitude, latCurrent, lonCurrent)
    }

}