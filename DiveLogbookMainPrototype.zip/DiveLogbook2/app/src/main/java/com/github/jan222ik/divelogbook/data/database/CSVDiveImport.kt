package com.github.jan222ik.divelogbook.data.database

import androidx.lifecycle.MutableLiveData
import com.github.doyaaaaaken.kotlincsv.dsl.csvReader
import com.github.jan222ik.divelogbook.data.database.db.DiveEntityDatabase
import com.github.jan222ik.divelogbook.data.database.entities.*
import java.io.InputStream
import java.lang.Exception
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.*
import java.util.concurrent.ArrayBlockingQueue

class CSVDiveImport(private val database: DiveEntityDatabase) {

    private val datePattern = DateTimeFormatter.ofPattern("dd.MM.yyyy")
    private val timePattern = DateTimeFormatter.ofPattern("HH:mm[:ss]")

    private fun readCSVRows(stream: InputStream): List<Map<String, String>> {
        return csvReader{
            delimiter = ';'
        }.readAllWithHeader(stream)
    }

    suspend fun readAll(divesStream: InputStream, locationsStream: InputStream) {
        val locationIDByName = readLocations(locationsStream)
        readDives(divesStream, MutableLiveData(), locationIDByName)
    }

    private suspend fun readDives(inputStream: InputStream, progress: MutableLiveData<IntRange>, locationIDsByName: Map<String, Long>) {
        val rows = readCSVRows(inputStream)
        progress.postValue(0..rows.size)
        for (dive in rows) {
            val depthEntity: DiveDepthEntity
            val temporalEntity: DiveTemporalEntity
            var locationID: Long?
            val diveNumber: Int
            try {
                diveNumber = dive[DIVE_NUMBER]?.toIntOrNull() ?: -1

                depthEntity = DiveDepthEntity(
                    maxMetric = dive[DEPTH_MAX]?.replace(',', '.')?.toDoubleOrNull()?.times(10)?.toInt(),
                    avgMetric = dive[DEPTH_AVG]?.replace(',', '.')?.toDoubleOrNull()?.times(10)?.toInt()
                )

                val date = LocalDate.parse(
                    if (!dive[TEMP_DATE].isNullOrEmpty()) dive[TEMP_DATE] else LocalDate.now().format(datePattern),
                    datePattern
                )
                temporalEntity = DiveTemporalEntity(
                    durationSec = dive[TEMP_DURATION]?.toIntOrNull() ?: 0,
                    dateTimeIn = LocalDateTime.of(date, dive[TEMP_ENTRY].cleanInput(LocalTime.MIN) { LocalTime.parse(it, timePattern) }),
                    dateTimeOut = LocalDateTime.of(date, dive[TEMP_EXIT].cleanInput(LocalTime.MIN) { LocalTime.parse(it, timePattern) })
                )

                locationID = locationIDsByName[dive[DIVE_LOC]]
                if (locationID == null && dive[DIVE_LOC] != null) {
                    val spotID = database.diveSpotDao().insert(DiveSpotEntity(dive[DIVE_LOC]!!, null, null, null, null))
                    locationID = database.diveLocationDao().insert(DiveLocationEntity(spotID, null))
                }
            } catch (e: Exception) {
                continue
            }
            val depthID = database.diveDepthDao().insert(depthEntity)
            val temporalID = database.diveTemporalDao().insert(temporalEntity)
            val diveEntity = DiveEntity(temporalId = temporalID, depthId = depthID, locationId = locationID)
            val diveID = database.diveEntityDao().insert(diveEntity)
            val logbookDiveEntity = LogbookDiveEntity(diveNumber, diveID)
            database.logbookDiveDao().insert(logbookDiveEntity)
        }
    }

    fun <T> String?.cleanInput(default: T, block: (v: String) -> T) : T {
        return if (this == null || this.isEmpty()) {
            default
        } else block(this)
    }

    private suspend fun readLocations(stream: InputStream): Map<String, Long> {
        val rows = readCSVRows(stream)
        val map: HashMap<String, Long> = hashMapOf()
        rows.forEach { loc ->
            if (loc.isNotEmpty()) { // Skips empty lines
                val addressEntity = AddressEntity(
                    country = loc[ADD_COUNTRY]!!,
                    city = loc[ADD_CITY],
                    zip = loc[ADD_ZIP],
                    street = loc[ADD_STREET],
                    houseNumber = loc[ADD_HOUSE]
                )
                val addressID = database.addressDao().insert(addressEntity)
                val spotEntity = DiveSpotEntity(
                    spotName = loc[LOC_SPOT]!!,
                    bodyOfWater = loc[LOC_BODY_OF_WATER],
                    altitude = loc[LOC_ALTITUDE]?.toInt() ?: 0,
                    longitude = loc[LOC_LON]?.toDoubleOrNull(),
                    latitude = loc[LOC_LAT]?.toDoubleOrNull()
                )
                val spotID = database.diveSpotDao().insert(spotEntity)

                val locationEntity = DiveLocationEntity(
                    addressEntityId = addressID,
                    spotEntityId = spotID
                )
                map[spotEntity.spotName] = database.diveLocationDao().insert(locationEntity)
            }
        }
        return map
    }

    companion object {
        // DIVE
        const val DIVE_LOC = "name"
        const val DIVE_NUMBER = "diveNumber"
        // DEPTH
        const val DEPTH_MAX = "max"
        const val DEPTH_AVG = "avg"
        // TEMPORAL
        const val TEMP_DATE = "date"
        const val TEMP_DURATION = "duration"
        const val TEMP_ENTRY = "timeIn"
        const val TEMP_EXIT = "timeOut"
        const val TEMP_SURFACE_TIME = "surfaceTime"
        // LOCATION
        const val LOC_SPOT = "spotName"
        const val LOC_BODY_OF_WATER = "bodyOfWater"
        const val LOC_ALTITUDE = "altitude"
        const val LOC_LON = "longitude"
        const val LOC_LAT = "latitude"
        // ADDRESS
        const val ADD_COUNTRY = "country"
        const val ADD_ZIP = "zip"
        const val ADD_CITY = "city"
        const val ADD_STREET = "street"
        const val ADD_HOUSE = "house"
    }
}


