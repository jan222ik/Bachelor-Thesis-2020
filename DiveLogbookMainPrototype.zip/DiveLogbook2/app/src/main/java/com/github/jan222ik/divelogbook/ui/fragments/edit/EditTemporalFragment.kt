package com.github.jan222ik.divelogbook.ui.fragments.edit

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.icu.util.Calendar
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.activity.addCallback
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.Edit
import com.github.jan222ik.divelogbook.data.updateAsUser
import com.github.jan222ik.divelogbook.ui.viewmodel.EditViewModel
import kotlinx.android.synthetic.main.fragment_edit_common_nav.view.*
import kotlinx.android.synthetic.main.fragment_edit_temporal.view.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter


class EditTemporalFragment : Fragment() {

    lateinit var navController: NavController
    lateinit var editViewModel: EditViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner) {
            editViewModel.setPreviousChainFragment {
                navController.popBackStack()
            }
            navController.navigateUp()
        }
        return inflater.inflate(R.layout.fragment_edit_temporal, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        editViewModel = ViewModelProviders.of(requireActivity()).get(EditViewModel::class.java)
        with(view.nextBtn) {
            setOnClickListener {
                editViewModel.temporalEdit.allToUser()
                editViewModel.setNextChainFragment()
                navController.navigate(EditTemporalFragmentDirections.actionEditTemporalFragmentToEditModulesFragment())
            }
        }
        with(view.editDiveDate) date@{
            setRawInputType(InputType.TYPE_CLASS_TEXT)
            setTextIsSelectable(false)
            setOnClickListener {
                val c = Calendar.getInstance()
                val yearC = c.get(Calendar.YEAR)
                val month = c.get(Calendar.MONTH)
                val day = c.get(Calendar.DAY_OF_MONTH)

                val onDateSetListener = DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
                    val value = LocalDate.of(year, monthOfYear, dayOfMonth)
                    with(editViewModel.temporalEdit) {
                        date.setValue(date.getValue().updateAsUser(value), this@date)
                    }
                    textString = value.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
                }

                val dpd = DatePickerDialog(requireActivity(), onDateSetListener, yearC, month, day)

                dpd.show()
            }
            with(editViewModel.temporalEdit) {
                durationSec.addDependant { _, n, _ -> view.editDurationLayout?.updateIcon(n, resources) }
                date.addDependant { _, n, _ -> view.editDateLayout?.updateIcon(n, resources) }
                entryTime.addDependant { _, n, _ -> view.editTimeEntryLayout?.updateIcon(n, resources) }
                exitTime.addDependant { _, n, _ -> view.editTimeExitLayout?.updateIcon(n, resources) }

                if (date.getValue().value == null) {
                    date.setValue(Edit.PredictionBy.Calculated(LocalDate.now()))
                }
                textString = date.getValue().value!!.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
            }
        }

        with(view.editDuration) {
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable) {}
                override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                    with(editViewModel.temporalEdit) {
                        val newValue = view.editDuration.textString.safeDouble()?.times(60)?.toInt()
                        Log.d("TAG", "onTextChanged: Duration" + newValue)
                        if (newValue != null) {
                            durationSec.setValue(Edit.ByUser(newValue))
                        }
                    }
                }
            })
            with(editViewModel.temporalEdit) {
                textString = (durationSec.getValue().value!! / 60).toString()
            }
        }

        with(view.editTimeEntry) {
            setOnClickListener {
                timePicker(TimePickerDialog.OnTimeSetListener { _, h, m ->
                    val time = LocalTime.of(h, m)
                    with(editViewModel.temporalEdit) {
                        entryTime.setValue(entryTime.getValue().updateAsUser(time))
                    }
                    textString = time.format(DateTimeFormatter.ofPattern("hh:mm"))
                })
            }
            with(editViewModel.temporalEdit) {
                if (entryTime.getValue().value == null) {
                    entryTime.setValue(Edit.PredictionBy.Calculated(LocalTime.now()))
                }
                textString = entryTime.getValue().value!!.format(DateTimeFormatter.ofPattern("hh:mm"))
            }
        }

        with(view.editTimeExit) {
            setOnClickListener {
                timePicker(TimePickerDialog.OnTimeSetListener { _, h, m ->
                    val time = LocalTime.of(h, m)
                    with(editViewModel.temporalEdit) {
                        exitTime.setValue(exitTime.getValue().updateAsUser(time))
                    }
                    textString = time.format(DateTimeFormatter.ofPattern("hh:mm"))
                })
            }
            with(editViewModel.temporalEdit) {
                if (exitTime.getValue().value == null) {
                    exitTime.setValue(Edit.PredictionBy.Calculated(LocalTime.now()))
                }
                exitTime.addDependant(updateAfterAdd = true) { _, newValue, _ ->
                    textString = newValue.value!!.format(DateTimeFormatter.ofPattern("hh:mm"))
                }
            }
        }
    }

    private fun timePicker(listener: TimePickerDialog.OnTimeSetListener) {
        val c = Calendar.getInstance()
        val hour = c.get(Calendar.HOUR)
        val minute = c.get(Calendar.MINUTE)

        val tpd = TimePickerDialog(requireActivity(), listener, hour, minute, true)
        tpd.show()
    }

    private var EditText.textString
        get() = this.text.toString()
        set(value) = this.setText(value)


}