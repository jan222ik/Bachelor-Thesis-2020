package com.github.jan222ik.divelogbook.ui.fragments.edit

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.addCallback
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.ui.viewmodel.EditViewModel
import com.github.jan222ik.divelogbook.ui.viewmodel.LogbookViewModel
import kotlinx.android.synthetic.main.fragment_edit_host.view.*
import kotlinx.coroutines.runBlocking


class EditHostFragment : Fragment() {

    lateinit var editModel: EditViewModel
    lateinit var logbookViewModel: LogbookViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        editModel = ViewModelProviders.of(requireActivity()).get(EditViewModel::class.java)
        logbookViewModel = ViewModelProviders.of(requireActivity()).get(LogbookViewModel::class.java)
        editModel.init(runBlocking { logbookViewModel.getEdit() })
        editModel.initModuleData()
        editModel.moduleListConfigName.postValue(null) //TODO LOAD RIGHT CONFIG
        editModel.initChainFragmentNav(null)
        return inflater.inflate(R.layout.fragment_edit_host, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val cumulativeCounts = editModel.cumulativeCounts
        cumulativeCounts.observe(requireActivity(), Observer {
            Toast.makeText(requireActivity(), it.toString(), Toast.LENGTH_SHORT).show()
            with(view.progressBar) {
                max = it.totalFields
                secondaryProgress = it.byUser + it.byPredictions
                progress = it.byUser
            }
        })
    }

}