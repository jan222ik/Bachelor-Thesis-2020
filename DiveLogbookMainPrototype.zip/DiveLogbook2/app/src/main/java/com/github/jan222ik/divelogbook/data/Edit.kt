package com.github.jan222ik.divelogbook.data

sealed class Edit<T>(open var value: T?) {

    sealed class PredictionBy<T>(override var value: T?) : Edit<T>(value) {
        data class Camera<T>(override var value: T?, val confidence: Float) :
            Edit.PredictionBy<T>(value)

        data class History<T>(override var value: T?) : Edit.PredictionBy<T>(value)
        data class Calculated<T>(override var value: T?) : Edit.PredictionBy<T>(value)
        data class Sensor<T>(override var value: T?) : Edit.PredictionBy<T>(value)
    }

    data class ByUser<T>(override var value: T? = null) : Edit<T>(value)
    data class Unclaimed<T>(override var value: T? = null) : Edit<T>(value)
}

fun <T> Edit<T>.toUser(): Edit.ByUser<T> = Edit.ByUser(value)

fun <T> Edit<T>.update(value: T?): Edit<T> {
    return if (this !is Edit.Unclaimed) {
        Edit.ByUser(value)
    } else this
}

fun <T> Edit<T>.updateAsUser(value: T?): Edit<T> {
    return Edit.ByUser(value)
}

fun <T> Edit<T>.nullValueToUnclaimed(): Edit<T> = if (this.value == null) Edit.Unclaimed(value) else this