package com.github.jan222ik.divelogbook.ui.fragments.edit

object InputSanitizers {



}

fun String.safeDouble() : Double? = this.replace("[^0-9-]".toRegex(), "").toDoubleOrNull()