package com.github.jan222ik.divelogbook.data.database.daos

import androidx.room.*
import com.github.jan222ik.divelogbook.data.database.entities.DiveEntity
import com.github.jan222ik.divelogbook.data.database.pojos.SingleDiveData

@Dao
interface DiveEntityDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(diveEntity: DiveEntity): Long

    @Update
    suspend fun update(diveEntity: DiveEntity)

    @Query("DELETE FROM dive")
    suspend fun deleteAll()

    @Query("Select * FROM dive Where diveId = :diveId")
    suspend fun getById(diveId: Long): DiveEntity

    @Transaction
    @Query("Select * FROM dive Where diveId = :diveId")
    suspend fun getSingleById(diveId: Long): SingleDiveData
}