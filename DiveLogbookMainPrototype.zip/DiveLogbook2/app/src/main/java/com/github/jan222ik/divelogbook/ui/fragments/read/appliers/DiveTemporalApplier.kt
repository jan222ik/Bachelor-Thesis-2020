package com.github.jan222ik.divelogbook.ui.fragments.read.appliers

import android.view.View
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.database.entities.DiveTemporalEntity
import com.github.jan222ik.divelogbook.data.minWithSec
import kotlinx.android.synthetic.main.detail_dive_temporal.view.*
import java.time.format.DateTimeFormatter


object DiveTemporalApplier {
    private val formatter = DateTimeFormatter.ofPattern("hh:mm dd.MM.YYYY")

    fun apply(view: View, temporal: DiveTemporalEntity) {
        with(view) {
            val missing = lazy { resources.getString(R.string.missingData) }
            temporalDuration.text = temporal.durationSec.minWithSec()
            temporalEntryDateTime.text = temporal.dateTimeIn?.format(formatter) ?: missing.value
            temporalExitDateTime.text = temporal.dateTimeOut?.format(formatter) ?: missing.value
        }
    }
}