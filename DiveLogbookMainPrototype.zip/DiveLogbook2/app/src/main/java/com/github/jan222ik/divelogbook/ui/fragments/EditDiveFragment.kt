package com.github.jan222ik.divelogbook.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.lifecycle.liveData
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.database.pojos.LogbookDive
import com.github.jan222ik.divelogbook.ui.viewmodel.LogbookViewModel
import kotlinx.android.synthetic.main.fragment_edit_dive.*
import kotlinx.coroutines.runBlocking
import java.time.LocalDate

class EditDiveFragment : Fragment() {

    private var item: LogbookDive? = null
    private var model: LogbookViewModel? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_edit_dive, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        model = ViewModelProviders.of(requireActivity()).get(LogbookViewModel::class.java)
        liveData {
            val edit = model!!.getEdit()
            emit(edit)
        }.observe(requireActivity(), Observer {
            item = it
            if (it != null) {
                editTextNumberOFDive.textString = it.logbookDiveEntity.diveNumber.nullToEmptyString()

                editTextDateOFDive.textString = LocalDate.now().nullToEmptyString()

                editTextDepthMax.textString = it.diveData?.depth?.maxMetric.nullToEmptyString()
                editTextDepthAvg.textString = it.diveData?.depth?.avgMetric.nullToEmptyString()
            }
        })
        finishEditBtn.setOnClickListener {
            updateModelFromFields()
            runBlocking {
                model!!.updateEditEntry()
                Toast.makeText(requireActivity(),"Updated", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateModelFromFields() {
        if (item != null) {
            item!!.logbookDiveEntity.diveNumber = editTextNumberOFDive.textString.toInt()
        }
    }

    private fun Any?.nullToEmptyString():String {
        return this?.toString() ?: ""
    }

    private var EditText.textString
    get() = this.text.toString()
    set(value) = this.setText(value)

}