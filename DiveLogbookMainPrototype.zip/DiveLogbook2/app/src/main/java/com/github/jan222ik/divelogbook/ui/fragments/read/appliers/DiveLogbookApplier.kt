package com.github.jan222ik.divelogbook.ui.fragments.read.appliers

import android.view.View
import com.github.jan222ik.divelogbook.data.database.entities.LogbookDiveEntity
import kotlinx.android.synthetic.main.detail_dive_logbook.view.*


object DiveLogbookApplier {
    fun apply(view: View, logbookDive: LogbookDiveEntity) {
        view.logbookDiveNumber.text = logbookDive.diveNumber.toString()
    }
}