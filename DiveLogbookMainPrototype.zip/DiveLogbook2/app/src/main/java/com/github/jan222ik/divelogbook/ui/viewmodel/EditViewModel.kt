package com.github.jan222ik.divelogbook.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.*
import androidx.navigation.NavDirections
import com.github.jan222ik.divelogbook.data.Edit
import com.github.jan222ik.divelogbook.data.database.daos.DiveLocationDao
import com.github.jan222ik.divelogbook.data.database.db.DiveEntityDatabase
import com.github.jan222ik.divelogbook.data.database.db.Lazy
import com.github.jan222ik.divelogbook.data.database.entities.DiveCommentEntity
import com.github.jan222ik.divelogbook.data.database.entities.DiveDepthEntity
import com.github.jan222ik.divelogbook.data.database.entities.DiveTemporalEntity
import com.github.jan222ik.divelogbook.data.database.entities.LogbookDiveEntity
import com.github.jan222ik.divelogbook.data.database.pojos.DiveLocation
import com.github.jan222ik.divelogbook.data.database.pojos.LogbookDive
import com.github.jan222ik.divelogbook.data.database.pojos.SingleDiveData
import com.github.jan222ik.divelogbook.data.nullValueToUnclaimed
import com.github.jan222ik.divelogbook.data.repo.LogbookDiveRepo
import com.github.jan222ik.divelogbook.data.repo.SingleDiveDataRepo
import com.github.jan222ik.divelogbook.data.toUser
import com.github.jan222ik.divelogbook.mapper.MapperDelegate
import com.github.jan222ik.divelogbook.ui.fragments.edit.EditModulesFragmentDirections
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.runBlocking
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import kotlin.properties.Delegates

class EditViewModel(application: Application) : AndroidViewModel(application) {

    private val db = DiveEntityDatabase.getDatabase(application, viewModelScope)
    private val singleDiveDataRepo = SingleDiveDataRepo(
        db.diveEntityDao(),
        db.diveDepthDao(),
        db.diveTemporalDao(),
        db.diveSpotDao(),
        db.diveLocationDao(),
        db.diveCommentDao(),
        db.diveGasMixtureDao(),
        db.addressDao()
    )
    private val logbookDiveRepo = LogbookDiveRepo(db.logbookDiveDao(), singleDiveDataRepo)


    private var data: LogbookDive? = null

    lateinit var logbookEdit: LogbookEdit
    lateinit var depthEdit: DepthEdit
    lateinit var temporalEdit: TemporalEdit
    lateinit var locationRefEdit: LocationRefEdit
    lateinit var commentEdit: CommentEdit

    lateinit var cumulativeCounts: LiveData<FieldCount>


    fun init(dive: LogbookDive? = null) {
        data = dive
        logbookEdit = LogbookEdit(_number = Edit.PredictionBy.History(runBlocking(IO) { db.logbookDiveDao().getLatestNumber() } + 1))
        depthEdit = DepthEdit()
        temporalEdit = TemporalEdit()
        locationRefEdit = LocationRefEdit(locationDao = db.diveLocationDao())
        commentEdit = CommentEdit()

        val block: (FieldCount, FieldCount) -> FieldCount = { c0, c1 -> c0 + c1 }
        cumulativeCounts = depthEdit.counts
            .combineFieldCounts(temporalEdit.counts, block)
            .combineFieldCounts(locationRefEdit.counts, block)
            .combineFieldCounts(logbookEdit.counts, block)
            .combineFieldCounts(commentEdit.counts, block)
        if (data != null) {
            logbookEdit.applyFromExisting(data)
            depthEdit.applyFromExisting(data?.diveData?.depth)
            temporalEdit.applyFromExisting(data?.diveData?.temporal)
        }
        locationRefEdit.applyFromExisting(data?.diveData?.location?.entity?.locationId)
        commentEdit.applyFromExisting(data?.diveData?.comment)

        temporalEdit.initDependencyConnections()
    }

    suspend fun save() {
        val newDepth = depthEdit.toDomainObject()
        val newTemporal = temporalEdit.toDomainObject()
        val newLocation = locationRefEdit.location.value
        val newComment = commentEdit.toDomainObject()
        val singleDiveData = SingleDiveData(null, newDepth, newTemporal)
        singleDiveData.location = newLocation
        singleDiveData.commentLazy = Lazy.ofInitial(newComment)
        singleDiveData.comment = newComment
        data = logbookEdit.toDomainObject()
        with(data!!) {
            if (diveData == null) {
                diveData = singleDiveData
            } else {
                singleDiveData.diveEntity = diveData?.diveEntity
                diveData = singleDiveData
            }
        }
        logbookDiveRepo.upsertLogbookDive(data!!)
    }

    fun isNew(): Boolean {
        return data == null
    }

    /*
        Edit Modules Navigation Behavior
    */

    private var currentChainNumber: Int? = null
    private var chainModules = runBlocking(IO) { db.editModuleConfigEntitiesDao().getByConfigName(null.toString()) }

    fun initChainFragmentNav(configName: String?) {
        currentChainNumber = runBlocking(IO) {
            db.editModuleConfigEntitiesDao().getByConfigName(configName.toString()).find { it.chain && it.chainNumber == 0 }?.chainNumber
        }
    }

    fun forceModuleView() {
        currentChainNumber = null
    }

    fun getCurrentChainNavDirection(): NavDirections? {
        return if (currentChainNumber != null) {
            val find = chainModules.find { it.chain && it.chainNumber == currentChainNumber!! }
            if (find != null) EditNames.valueOf(find.name).direction else null
        } else null
    }

    fun setPreviousChainFragment(pop2MaintainChain: () -> Unit = {}) {
        val old = currentChainNumber
        currentChainNumber = if (currentChainNumber != null) {
            chainModules.find { it.chain && it.chainNumber == currentChainNumber!! - 1 }?.chainNumber
        } else null
        if (old != null) {
            pop2MaintainChain()
        }
    }


    fun setNextChainFragment() {
        currentChainNumber = if (currentChainNumber != null) {
            chainModules.find { it.chain && it.chainNumber == currentChainNumber!! + 1 }?.chainNumber
        } else null
    }

    val moduleListConfigName: MutableLiveData<String?> = MutableLiveData(null)

    lateinit var moduleListData: LiveData<List<EditModuleItemData>>


    fun initModuleData() {
        moduleListData = Transformations.switchMap<String, List<EditModuleItemData>>(moduleListConfigName)
        { configName: String? ->
            return@switchMap liveData(IO) {
                val resultByConfigName = db.editModuleConfigEntitiesDao().getByConfigName(configName.toString())
                chainModules = resultByConfigName
                emit(resultByConfigName.map { e ->
                    return@map EditModuleItemData(
                        e.name,
                        e.oder,
                        e.chain,
                        e.chainNumber,
                        EditNames.valueOf(e.name).direction
                    )
                })
            }
        }

        moduleListConfigName.postValue(null)
    }

}

enum class EditNames(val direction: NavDirections) {
    GENERAL(EditModulesFragmentDirections.actionEditModulesFragmentToEditLogbookDiveFragment()),
    DEPTH(EditModulesFragmentDirections.actionEditModulesFragmentToEditDepthFragment()),
    TEMPORAL(EditModulesFragmentDirections.actionEditModulesFragmentToEditTemporalFragment()),
    LOCATION(EditModulesFragmentDirections.actionEditModulesFragmentToEditLocationRefSelectedFragment()),
    COMMENT(EditModulesFragmentDirections.actionEditModulesFragmentToEditCommentFragment()),
    GAS_MIXTURE(EditModulesFragmentDirections.actionEditModulesFragmentToEditGasMixtureFragment()),
    RATING(EditModulesFragmentDirections.actionEditModulesFragmentToEditRatingFragment())
}

sealed class AbstractEdit<T> {

    abstract val counts: MutableLiveData<FieldCount>
    abstract fun applyFromExisting(data: T?)
    abstract fun toDomainObject(): T
    abstract fun allToUser()
    open fun initDependencyConnections() {}
}

data class FieldCount(
    var byUser: Int = 0,
    var byCamera: Int = 0,
    var byHistory: Int = 0,
    var byCalculated: Int = 0,
    var bySensor: Int = 0,
    var unclaimed: Int = 0
) {

    val byPredictions: Int
        get() = byCamera + byHistory + byCalculated + bySensor
    val totalFields: Int
        get() = byPredictions + byUser + unclaimed

    companion object {

        fun count(edits: List<Edit<*>>): FieldCount {
            val count = FieldCount()
            edits.forEach {
                when (it) {
                    is Edit.PredictionBy.Camera -> count.byCamera++
                    is Edit.PredictionBy.History -> count.byHistory++
                    is Edit.PredictionBy.Calculated -> count.byCalculated++
                    is Edit.PredictionBy.Sensor -> count.bySensor++
                    is Edit.ByUser -> count.byUser++
                    is Edit.Unclaimed -> count.unclaimed++
                }
            }
            return count
        }
    }

    operator fun plus(other: FieldCount) = FieldCount(
        byUser + other.byUser,
        byCamera + other.byCamera,
        byHistory + other.byHistory,
        byCalculated + other.byCalculated,
        bySensor + other.bySensor,
        unclaimed + other.unclaimed
    )

}

class CommentEdit(
    initComment: Edit<String> = Edit.Unclaimed()
) : AbstractEdit<DiveCommentEntity?>() {
    val comment: MapperDelegate<Edit<String>> = MapperDelegate(value = initComment)

    override val counts: MutableLiveData<FieldCount> = MutableLiveData(FieldCount.count(listOf(comment.getValue())))

    override fun applyFromExisting(data: DiveCommentEntity?) {
        if (data != null) {
            comment.setValue(Edit.ByUser(data.comment))
        }
    }

    override fun toDomainObject(): DiveCommentEntity? =
        if (!comment.getValue().value.isNullOrEmpty()) DiveCommentEntity(comment.getValue().value!!) else null

    override fun allToUser() {
        if (!comment.getValue().value.isNullOrEmpty()) comment.setValue(Edit.ByUser(comment.getValue().value))
    }

}

data class LogbookEdit(
    private var _number: Edit<Int> = Edit.Unclaimed()
) : AbstractEdit<LogbookDive>() {
    private var singleDiveData: SingleDiveData? = null
    private var entity: LogbookDiveEntity? = null

    var number: Edit<Int> by Delegates.observable(_number) { _, _, newValue ->
        _number = newValue
        counts.postValue(FieldCount.count(listOf(number)))
    }

    override val counts: MutableLiveData<FieldCount> = MutableLiveData(FieldCount.count(listOf(number)))

    override fun applyFromExisting(data: LogbookDive?) {
        if (data != null) {
            singleDiveData = data.diveData
            entity = data.logbookDiveEntity
            number = Edit.ByUser(data.logbookDiveEntity.diveNumber).nullValueToUnclaimed()
        }
    }

    override fun toDomainObject(): LogbookDive {
        val newEntity = LogbookDiveEntity(number.value ?: -1, entity?.diveId)
        val newLogbookDive = LogbookDive(newEntity)
        newLogbookDive.diveData = singleDiveData
        return newLogbookDive
    }

    override fun allToUser() {
        TODO("allToUser not implemented")
    }
}

data class LocationRefEdit(
    private var _locationRef: Edit<Long> = Edit.Unclaimed(),
    private var locationDao: DiveLocationDao
) : AbstractEdit<Long?>() {
    lateinit var location: LiveData<DiveLocation?>
    private var locUpdate = MutableLiveData<Edit<Long>>()
    var locationRef: Edit<Long> by Delegates.observable(_locationRef) { _, oldValue, newValue ->
        if (oldValue != newValue) {
            _locationRef = newValue
            locUpdate.postValue(newValue)
            counts.postValue(FieldCount.count(listOf(locationRef)))
        }
    }
    override val counts: MutableLiveData<FieldCount> = MutableLiveData(FieldCount.count(listOf(locationRef)))

    override fun applyFromExisting(data: Long?) {
        location = Transformations.switchMap<Edit<Long>, DiveLocation?>(locUpdate)
        { editId ->
            if (editId.value == null) {
                return@switchMap liveData { emit(null as DiveLocation?) }
            } else {
                return@switchMap locationDao.getLivePojoById(editId.value!!)
            }
        }
        locationRef = Edit.ByUser(data).nullValueToUnclaimed()
        locUpdate.postValue(locationRef)
    }

    override fun toDomainObject(): Long? = locationRef.value
    override fun allToUser() {
        TODO("allToUser not implemented")
    }
}


data class DepthEdit(
    private var _max: Edit<Int> = Edit.Unclaimed(),
    private var _avg: Edit<Int> = Edit.Unclaimed()
) : AbstractEdit<DiveDepthEntity>() {
    private var depthId: Long? = null

    var max: Edit<Int> by Delegates.observable(_max) { _, oldValue, newValue ->
        if (oldValue != newValue) {
            _max = newValue
            counts.postValue(FieldCount.count(listOf(max, avg)))
        }
    }

    var avg: Edit<Int> by Delegates.observable(_avg) { _, oldValue, newValue ->
        if (oldValue != newValue) {
            _avg = newValue
            counts.postValue(FieldCount.count(listOf(max, avg)))
        }
    }
    override val counts: MutableLiveData<FieldCount> =
        MutableLiveData(FieldCount.count(listOf(max, avg)))

    override fun applyFromExisting(data: DiveDepthEntity?) {
        if (data != null) {
            max = Edit.ByUser(data.maxMetric).nullValueToUnclaimed()
            avg = Edit.ByUser(data.avgMetric).nullValueToUnclaimed()
            depthId = data.depthId
        }
    }

    override fun toDomainObject(): DiveDepthEntity {
        val entity = DiveDepthEntity(max.value, avg.value)
        entity.depthId = depthId
        return entity
    }

    override fun allToUser() {
        TODO("allToUser not implemented")
    }
}

class TemporalEdit(
    initDurationSec: Edit<Int> = Edit.Unclaimed(0),
    initDate: Edit<LocalDate> = Edit.PredictionBy.Calculated(LocalDate.now()),
    initTimeEntry: Edit<LocalTime> = Edit.Unclaimed(),
    initTimeExit: Edit<LocalTime> = Edit.Unclaimed()
) : AbstractEdit<DiveTemporalEntity>() {

    var durationSec = MapperDelegate(initDurationSec, "DurationSec") { _, it -> it.value != null && it.value!! >= 0 }
    var date = MapperDelegate(initDate, "Date")
    var entryTime = MapperDelegate(initTimeEntry, "EntryTime")
    var exitTime = MapperDelegate(initTimeExit, "ExitTime")

    init {
        val updateFieldCount: (oldValue: Edit<*>, newValue: Edit<*>, originObject: Any?) -> Unit = { _, _, _ ->
            counts.postValue(FieldCount.count(uiFields()))
        }
        durationSec.addDependant(updateFieldCount)
        date.addDependant(updateFieldCount)
        entryTime.addDependant(updateFieldCount)
        exitTime.addDependant(updateFieldCount)
    }

    private var temporalId: Long? = null

    private fun uiFields() = listOf(date.getValue(), durationSec.getValue(), entryTime.getValue(), exitTime.getValue())
    override val counts: MutableLiveData<FieldCount> = MutableLiveData(FieldCount.count(uiFields()))

    override fun applyFromExisting(data: DiveTemporalEntity?) {
        if (data != null) {
            temporalId = data.diveTemporalId
            durationSec.setValue(if (data.durationSec != 0) Edit.ByUser(data.durationSec) else Edit.Unclaimed(0))
            date.setValue(Edit.ByUser(data.dateTimeIn?.toLocalDate()).nullValueToUnclaimed())
            entryTime.setValue(Edit.ByUser(data.dateTimeIn?.toLocalTime()).nullValueToUnclaimed())
            exitTime.setValue(Edit.ByUser(data.dateTimeOut?.toLocalTime()).nullValueToUnclaimed())
        }
    }

    override fun initDependencyConnections() {
        val calcExitTime = {
            if (exitTime !is Edit.ByUser<*>) {
                val enT = entryTime.getValue()
                val dur = durationSec.getValue()
                val newValue = enT.value?.plusSeconds(dur.value?.toLong() ?: 0L)
                exitTime.setValue(Edit.PredictionBy.Calculated(newValue ?: (entryTime.getValue().value ?: LocalTime.now())))
            }
        }
        entryTime.addDependant(true) {_, _, _ -> println("Called"); calcExitTime()}
        durationSec.addDependant(true) {_, _, _ -> println("Called");calcExitTime()}
    }

    override fun toDomainObject(): DiveTemporalEntity {
        val enter = if (entryTime.getValue().value != null) {
            LocalDateTime.of(date.getValue().value, entryTime.getValue().value)
        } else null
        //TODO check if time overlap -> change exit date to next day
        val exit = if (exitTime.getValue().value != null) {
            LocalDateTime.of(date.getValue().value, exitTime.getValue().value)
        } else null
        val entity = DiveTemporalEntity(durationSec.getValue().value ?: 0, enter, exit)
        entity.diveTemporalId = temporalId
        return entity
    }

    override fun allToUser() {
        durationSec.setValue(durationSec.getValue().toUser())
        date.setValue(date.getValue().toUser())
        entryTime.setValue(entryTime.getValue().toUser())
        exitTime.setValue(exitTime.getValue().toUser())
    }


}

private fun LiveData<FieldCount>.combineFieldCounts(
    liveData: LiveData<FieldCount>,
    block: (FieldCount, FieldCount) -> FieldCount
): LiveData<FieldCount> {
    val result = MediatorLiveData<FieldCount>()
    result.addSource(this) {
        result.value = block.invoke(this.value!!, liveData.value!!)
    }
    result.addSource(liveData) {
        result.value = block.invoke(this.value!!, liveData.value!!)
    }
    return result
}


data class EditModuleItemData(
    val name: String,
    val orderNumber: Int,
    val chain: Boolean,
    val chainNumber: Int?,
    val direction: NavDirections
)