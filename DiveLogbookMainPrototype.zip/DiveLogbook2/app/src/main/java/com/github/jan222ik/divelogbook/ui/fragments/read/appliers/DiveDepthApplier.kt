package com.github.jan222ik.divelogbook.ui.fragments.read.appliers

import android.view.View
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.database.entities.DiveDepthEntity
import com.github.jan222ik.divelogbook.data.m
import kotlinx.android.synthetic.main.detail_dive_depth.view.*

object DiveDepthApplier: DetailApplier<DiveDepthEntity> {
    override fun apply(view: View, data: DiveDepthEntity, hideEmpty: Boolean): Boolean {
        with(view) {
            var vis = false
            val missing = lazy { resources.getString(R.string.missingData) }
            val max = data.maxMetric?.m()
            val avg = data.avgMetric?.m()
            vis = vis and max.visibilityFor(listOf(depthMax, depthMaxLabel), hideEmpty)
            vis = vis and avg.visibilityFor(listOf(depthAvg, depthAvgLabel), hideEmpty)
            depthMax.text = max ?: missing.value
            depthAvg.text = avg ?: missing.value
            return vis
        }
    }

}