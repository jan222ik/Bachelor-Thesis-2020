package com.github.jan222ik.divelogbook.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import androidx.fragment.app.Fragment
import androidx.lifecycle.*
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.database.pojos.LogbookDive
import com.github.jan222ik.divelogbook.ui.fragments.read.appliers.*
import com.github.jan222ik.divelogbook.ui.viewmodel.LogbookViewModel
import kotlinx.android.synthetic.main.fragment_default_details.*
import kotlinx.android.synthetic.main.fragment_default_details.view.*

class DefaultDetailsFragment : Fragment() {

    lateinit var navController: NavController

    private var model: LogbookViewModel? = null
    private var showEmpty = MutableLiveData<Boolean>(true)


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_default_details, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        model = ViewModelProviders.of(requireActivity()).get(LogbookViewModel::class.java)
        view.findViewById<ImageButton>(R.id.editBtn).setOnClickListener {
            model!!.editDetails()
            navController.navigate(R.id.action_defaultDetailsFragment_to_editDiveFragment)
        }
        val liveData = liveData {
            emit(model!!.getDetail())
        }
        val combineWith = liveData.combineWith(showEmpty) { logbookDive: LogbookDive?, _: Boolean? -> logbookDive }
        combineWith.observe(viewLifecycleOwner, Observer {
            if (it != null) {
                DiveLogbookApplier.apply(view, it!!.logbookDiveEntity)
                if (DiveDepthApplier.apply(view, it.diveData!!.depth, showEmpty.value!!)) {
                    depthCard.visibility = View.GONE
                } else {
                    depthCard.visibility = View.VISIBLE
                }
                DiveTemporalApplier.apply(view, it.diveData!!.temporal)
                if (DiveLocationApplier.apply(view, it.diveData!!.location, showEmpty.value!!)) {
                    locationCard.visibility = View.GONE
                } else {
                    locationCard.visibility = View.VISIBLE
                }
                AddressApplier.apply(view, it.diveData!!.location?.address)

                if (DiveGasMixtureApplier.apply(view, it.diveData!!.gasMixture)) {
                    gasMixtureCard.visibility = View.GONE
                } else {
                    gasMixtureCard.visibility = View.VISIBLE
                }

                DiveCommentApplier.apply(view, it.diveData!!.comment)
            }
        })
        view.toggleHideBtn.setOnClickListener {
            showEmpty.postValue(showEmpty.value!!.not())
        }
    }

    fun <T, K, R> LiveData<T>.combineWith(
        liveData: LiveData<K>,
        block: (T?, K?) -> R
    ): LiveData<R> {
        val result = MediatorLiveData<R>()
        result.addSource(this) {
            result.value = block.invoke(this.value, liveData.value)
        }
        result.addSource(liveData) {
            result.value = block.invoke(this.value, liveData.value)
        }
        return result
    }

}