package com.github.jan222ik.divelogbook.ui.fragments.read

import `in`.gauriinfotech.commons.Commons
import android.app.Activity
import android.content.ContentResolver
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.ui.viewmodel.LogbookViewModel
import kotlinx.android.synthetic.main.fragment_import_c_s_v.*
import kotlinx.android.synthetic.main.fragment_import_c_s_v.view.*



class ImportCSVFragment : Fragment() {

    lateinit var navController: NavController
    private lateinit var viewModel: LogbookViewModel

    var _dives: Uri? = null
    var _location: Uri? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_import_c_s_v, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        viewModel = ViewModelProviders.of(requireActivity()).get(LogbookViewModel::class.java)

        view.divesCsvPickerBtn.setOnClickListener {
           pickCSV(READ_REQUEST_CODE_DIVES)
        }
        view.locationCsvPickerBtn.setOnClickListener {
            pickCSV(READ_REQUEST_CODE_LOCATIONS)
        }
    }

    private fun pickCSV(code: Int) {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "text/*"
        val createChooser = Intent.createChooser(intent, "Open CSV")
        startActivityForResult(createChooser, code)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        println("requestCode = [${requestCode}], resultCode = [${resultCode}], data = [${data}]")
        if (requestCode == READ_REQUEST_CODE_DIVES && resultCode == Activity.RESULT_OK) {
            _dives = data?.data
            divesCurrentPath.text = _dives?.path
        } else {
            _location = data?.data
            locationCurrentPath.text = _location?.path
        }
        if (_dives != null && _location != null) {
            viewModel.importCSV(
                requireActivity().contentResolver.openInputStream(_dives!!)!!,
                requireActivity().contentResolver.openInputStream(_location!!)!!
            ) {
                viewModel.invalidateLocations()
                viewModel.invalidateDives()
                viewModel.initDives()
                navController.navigateUp()
            }
        }
    }


    companion object {
        const val READ_REQUEST_CODE_DIVES = 123
        const val READ_REQUEST_CODE_LOCATIONS = 124
    }
}