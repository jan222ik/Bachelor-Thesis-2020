package com.github.jan222ik.divelogbook.data.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class DiveSpotEntity(
    val spotName: String,
    val bodyOfWater: String?,
    val altitude: Int?,
    val longitude: Double?,
    val latitude: Double?
) {
    @PrimaryKey
    var spotId: Long? = null
}