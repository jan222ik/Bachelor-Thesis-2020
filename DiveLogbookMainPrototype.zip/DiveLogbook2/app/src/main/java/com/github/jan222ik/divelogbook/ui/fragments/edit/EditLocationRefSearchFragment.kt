package com.github.jan222ik.divelogbook.ui.fragments.edit

import android.app.Dialog
import android.location.Location
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.Edit
import com.github.jan222ik.divelogbook.data.database.pojos.DiveLocation
import com.github.jan222ik.divelogbook.predictions.sensors.GPSBaseFragment
import com.github.jan222ik.divelogbook.ui.fragments.read.locationlist.LocationListAdapter
import com.github.jan222ik.divelogbook.ui.viewmodel.EditViewModel
import com.github.jan222ik.divelogbook.ui.viewmodel.LocationViewModel
import kotlinx.android.synthetic.main.filter_spot.*
import kotlinx.android.synthetic.main.fragment_edit_common_nav.view.*
import kotlinx.android.synthetic.main.fragment_edit_location_ref_search.*
import kotlinx.android.synthetic.main.fragment_edit_location_ref_search.view.*
import kotlinx.android.synthetic.main.fragment_edit_location_ref_search.view.filterByGPSBtn


class EditLocationRefSearchFragment : GPSBaseFragment(), LocationListAdapter.LocationListAdapterClickActions {

    lateinit var navController: NavController
    lateinit var editViewModel: EditViewModel
    lateinit var locationViewModel: LocationViewModel
    lateinit var wrappedList: MutableList<LocationListAdapter.DiveLocationWrapper>

    var latestLat: Double? = null
    var latestLon: Double? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_edit_location_ref_search, container, false)
        view.listEmptyNote.visibility = View.GONE
        locationViewModel = ViewModelProviders.of(requireActivity()).get(LocationViewModel::class.java)
        with(view.list as RecyclerView) {
            layoutManager = LinearLayoutManager(context)
            val realAdapter = LocationListAdapter(this@EditLocationRefSearchFragment)
            adapter = realAdapter

            locationViewModel.initLocation()
            locationViewModel.allLocations!!.observe(requireActivity(), Observer {
                Log.d("TAG", "onCreateView: Data refresh ${it.size}")
                if (it.size < 1) {
                    view.listEmptyNote.visibility = View.VISIBLE
                } else {
                    view.listEmptyNote.visibility = View.GONE
                }
                wrappedList = it.map { item -> return@map LocationListAdapter.DiveLocationWrapper(item, latestLat, latestLon) }.toMutableList()
                wrappedList = wrappedList.sortedBy { wrap -> wrap.distance ?: Double.MAX_VALUE}.toMutableList()
                realAdapter.submitList(wrappedList)
            })
            locationViewModel.applyLocationFilter()
        }
        return view
    }



    override fun updateLocationDependants(location: Location) {
        Log.d("ERR", "Location Update")
        if (filterByGPSBtn.isChecked) {
            latestLat = location.latitude
            latestLon = location.longitude
            wrappedList = wrappedList.map { item -> return@map LocationListAdapter.DiveLocationWrapper(item.diveLocation, latestLat, latestLon) }.toMutableList()
            wrappedList = wrappedList.sortedBy { wrap -> wrap.distance ?: Double.MAX_VALUE}.toMutableList()
            val recyclerView = requireView().list as RecyclerView
            val locationListAdapter = recyclerView.adapter as LocationListAdapter
            locationListAdapter.submitList(wrappedList)
            locationListAdapter.notifyDataSetChanged()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //init()
        navController = Navigation.findNavController(view)
        editViewModel = ViewModelProviders.of(requireActivity()).get(EditViewModel::class.java)

        //Skip Location Button
        with(view.nextBtn) {
            setOnClickListener {
                editViewModel.setNextChainFragment()
                navController.navigate(EditLocationRefSearchFragmentDirections.actionEditLocationRefSearchFragmentToEditModulesFragment())
            }
            text = requireActivity().getString(R.string.edit_skil_location)
        }

        with(view.filterLocationMixed) {
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable) {}
                override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                    val textString = view.filterLocationMixed.textString
                    if (textString.isNotEmpty()) {
                        locationViewModel.allLocationsFilter.postValue(LocationViewModel.LocationFilter(textString))
                    } else {
                        locationViewModel.allLocationsFilter.postValue(null)
                    }
                }
            })
        }

        with(view.fab) {
            setOnClickListener {
                locationViewModel.setEdit(null)
                navController.navigate(R.id.action_locationPagedListFragment_to_editSpotFragment)
            }
        }

        with(view.filterByGPSBtn) {
            setOnClickListener {
                if (this.isChecked) {
                    init()
                }
            }
        }
    }

    override fun onClickLocation(item: DiveLocation) {
        editViewModel.locationRefEdit.location.observe(this, Observer {
            if (it != null) {
                requireActivity().onBackPressed()
            }
        })
        editViewModel.locationRefEdit.locationRef = Edit.ByUser(item.entity.locationId)
    }

    private fun showFilterDialog() {
        val dialog = Dialog(requireActivity(), android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.filter_spot)
        val allUsedCountries = locationViewModel.getAllUsedCountries()
        dialog.selectCountry.setAdapter(ArrayAdapter<String>(requireActivity(), android.R.layout.simple_dropdown_item_1line, allUsedCountries))

        dialog.applyButton.setOnClickListener {
            val textString = dialog.selectCountry.textString
            if (textString.isNotEmpty()) {
                locationViewModel.updateFilter(
                    LocationViewModel.LocationFilter(
                        textString
                    )
                )
            }
            dialog.dismiss()
        }
        dialog.show()
    }


    private var EditText.textString
        get() = this.text.toString()
        set(value) = this.setText(value)
}