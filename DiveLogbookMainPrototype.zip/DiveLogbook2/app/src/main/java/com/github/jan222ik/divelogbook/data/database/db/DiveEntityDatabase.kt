package com.github.jan222ik.divelogbook.data.database.db

import android.content.Context
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.github.jan222ik.divelogbook.data.database.daos.*
import com.github.jan222ik.divelogbook.data.database.entities.*
import com.github.jan222ik.divelogbook.data.database.entities.config.EditModuleConfigEntity
import com.github.jan222ik.divelogbook.ui.viewmodel.EditNames
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDateTime

@Database(
    entities = [
        LogbookDiveEntity::class, DiveEntity::class, DiveDepthEntity::class, DiveLocationEntity::class,
        AddressEntity::class, DiveSpotEntity::class, DiveTemporalEntity::class, DiveCommentEntity::class,
        DiveGasMixtureEntity::class, DiveRatingEntity::class, EditModuleConfigEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(value = [Converters::class])
abstract class DiveEntityDatabase : RoomDatabase() {

    abstract fun logbookDiveDao(): LogbookDiveDao
    abstract fun diveEntityDao(): DiveEntityDao
    abstract fun diveDepthDao(): DiveDepthDao
    abstract fun diveSpotDao(): DiveSpotDao
    abstract fun diveLocationDao(): DiveLocationDao
    abstract fun diveTemporalDao(): DiveTemporalDao
    abstract fun diveCommentDao(): DiveCommentDao
    abstract fun diveGasMixtureDao(): DiveGasMixtureDao
    abstract fun addressDao(): AddressDao

    abstract fun editModuleConfigEntitiesDao(): EditModuleConfigEntriesDao

    companion object {
        @Volatile
        private var INSTANCE: DiveEntityDatabase? = null

        fun getDatabase(
            context: Context,
            scope: CoroutineScope
        ): DiveEntityDatabase {
            // if the INSTANCE is not null, then return it,
            // if it is, then create the database
            return INSTANCE
                ?: synchronized(this) {
                    val instance = Room.databaseBuilder(
                        context.applicationContext,
                        DiveEntityDatabase::class.java,
                        "dive_database"
                    )
                        .addCallback(
                            DiveDatabaseCallback(
                                scope
                            )
                        )
                        .build()
                    INSTANCE = instance
                    // return instance
                    instance
                }
        }

        private class DiveDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            /**
             * Override the onOpen method to populate the database.
             * For this sample, we clear the database every time it is created or opened.
             */
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                // If you want to keep the data through app restarts,
                // comment out the following line.
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateDatabase(
                            database.logbookDiveDao(),
                            database.diveEntityDao(),
                            database.diveDepthDao(),
                            database.diveLocationDao(),
                            database.diveSpotDao(),
                            database.diveTemporalDao(),
                            database.diveCommentDao(),
                            database.diveGasMixtureDao(),
                            database.addressDao(),
                            database.editModuleConfigEntitiesDao()
                        )
                        /*
                        demoData(
                            database.logbookDiveDao(),
                            database.diveEntityDao(),
                            database.diveDepthDao(),
                            database.diveLocationDao(),
                            database.diveSpotDao(),
                            database.diveTemporalDao(),
                            database.diveCommentDao(),
                            database.diveGasMixtureDao(),
                            database.addressDao(),
                            database.editModuleConfigEntitiesDao()
                        )
                         */
                    }
                }
            }
        }

        /**
         * Populate the database in a new coroutine.
         * If you want to start with more words, just add them.
         */
        suspend fun populateDatabase(
            logbookDiveDao: LogbookDiveDao,
            diveEntityDao: DiveEntityDao,
            diveDepthDao: DiveDepthDao,
            diveLocationDao: DiveLocationDao,
            diveSpotDao: DiveSpotDao,
            diveTemporalDao: DiveTemporalDao,
            diveCommentDao: DiveCommentDao,
            diveGasMixtureDao: DiveGasMixtureDao,
            addressDao: AddressDao,
            editModuleConfigEntitiesDao: EditModuleConfigEntriesDao
        ) {
            Log.d("DB", "populateDatabase: START DELETE ALL")
            logbookDiveDao.deleteAll()
            diveEntityDao.deleteAll()
            diveLocationDao.deleteAll()
            diveSpotDao.deleteAll()
            diveDepthDao.deleteAll()
            diveCommentDao.deleteAll()
            diveGasMixtureDao.deleteAll()
            addressDao.deleteAll()

            editModuleConfigEntitiesDao.deleteAll()
            Log.d("DB", "populateDatabase: END DELETE ALL ")

            Log.d("DB", "populateDatabase: Insert Edit Modules Config ")
            val default = null.toString()
            listOf(
                EditModuleConfigEntity(EditNames.GENERAL.name, 0, default, true, 0),
                EditModuleConfigEntity(EditNames.DEPTH.name, 1, default, true, 1),
                EditModuleConfigEntity(EditNames.TEMPORAL.name, 2, default, true, 2),
                EditModuleConfigEntity(EditNames.LOCATION.name, 3, default, true, 3),
                EditModuleConfigEntity(EditNames.COMMENT.name, 4, default),
                EditModuleConfigEntity(EditNames.RATING.name, 5, default),
                EditModuleConfigEntity(EditNames.GAS_MIXTURE.name, 6, default)
            ).forEach {
                Log.d("DB", "Add Config: $it")
                editModuleConfigEntitiesDao.insert(it)
            }
        }

        suspend fun demoData(
            logbookDiveDao: LogbookDiveDao,
            diveEntityDao: DiveEntityDao,
            diveDepthDao: DiveDepthDao,
            diveLocationDao: DiveLocationDao,
            diveSpotDao: DiveSpotDao,
            diveTemporalDao: DiveTemporalDao,
            diveCommentDao: DiveCommentDao,
            diveGasMixtureDao: DiveGasMixtureDao,
            addressDao: AddressDao,
            editModuleConfigEntitiesDao: EditModuleConfigEntriesDao
        ) {
            Log.d("DB", "populateDatabase: START INSERT")
            val countries = listOf("de", "egy", "us", "philippines", "se")
            val waterBodies = listOf("North Sea", "Red Sea", "Atlantic Ocean", "Pacific Ocean", "Baltic Sea")
            val locationIds = (1..200).map { i ->
                val addressId = addressDao.insert(
                    AddressEntity(
                        country = countries[i.rem(countries.size)],
                        zip = i.toString()
                    )
                )
                val spotId = diveSpotDao.insert(DiveSpotEntity("Spot $i", waterBodies[i.rem(waterBodies.size)], null, null, null))
                diveLocationDao.insert(DiveLocationEntity(spotId, addressId))
            }
            for (i in 1..2000) {
                Log.d("DB", "populateDatabase: INSERT NR $i")
                val depthId = diveDepthDao.insert(
                    DiveDepthEntity(
                        maxMetric = (10.0 + i % 20).toDbDepth(),
                        avgMetric = (5.0 + i % 10).toDbDepth()
                    )
                )
                val sec = 60 * 60
                val temporalId = diveTemporalDao.insert(
                    DiveTemporalEntity(
                        sec,
                        LocalDateTime.now(),
                        LocalDateTime.now().plusSeconds(sec.toLong())
                    )
                )
                val commentId: Long? =
                    if (i.rem(4) == 0) {
                        diveCommentDao.insert(DiveCommentEntity("Lol i am a comment from da database!"))
                    } else null
                val gasMixtureId: Long? = if (i.rem(4) == 0) {
                    diveGasMixtureDao.insert(DiveGasMixtureEntity(200, 50, 12, 1, 31))
                } else null
                val diveId = diveEntityDao.insert(
                    DiveEntity(
                        temporalId = temporalId,
                        depthId = depthId,
                        locationId = locationIds[i.rem(locationIds.size)],
                        gasMixtureId = gasMixtureId,
                        commentId = commentId
                    )
                )
                logbookDiveDao.insert(LogbookDiveEntity(100 + i, diveId))
            }
            Log.d("DB", "populateDatabase: END INSERT")
        }

    }

}

fun Double.toDbDepth(): Int = (this * 10).toInt()
