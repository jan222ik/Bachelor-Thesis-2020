package com.github.jan222ik.divelogbook.data.database.entities.config

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class EditModuleConfigEntity(
    val name: String,
    var oder: Int,
    var configItemName : String,
    var chain: Boolean = false,
    var chainNumber: Int? = null
) {
    @PrimaryKey(autoGenerate = true)
    var configItemId: Int? = null
}