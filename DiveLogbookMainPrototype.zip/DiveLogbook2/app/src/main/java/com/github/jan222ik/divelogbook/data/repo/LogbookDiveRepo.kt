package com.github.jan222ik.divelogbook.data.repo

import androidx.paging.DataSource
import com.github.jan222ik.divelogbook.data.database.daos.LogbookDiveDao
import com.github.jan222ik.divelogbook.data.database.pojos.LogbookDive
import com.github.jan222ik.divelogbook.ui.viewmodel.Filter
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.runBlocking

class LogbookDiveRepo(
    private val logbookDiveDao: LogbookDiveDao,
    private val singleDiveDataRepo: SingleDiveDataRepo
) {

    suspend fun getAll(): MutableList<LogbookDive> {
        val all = logbookDiveDao.getAll().toMutableList()
        for (it in all) {
            it.diveData = singleDiveDataRepo.getSingleDiveDataById(it.logbookDiveEntity.diveId!!)
        }
        return all
    }

    suspend fun getLogbookDiveById(id: Long): LogbookDive {
        val data = logbookDiveDao.getById(id)
        data.diveData = singleDiveDataRepo.getSingleDiveDataById(data.logbookDiveEntity.diveId!!)
        return data
    }

    fun getAllPaged(filter: Filter? = null): DataSource.Factory<Int, LogbookDive> {
        return logbookDiveDao.getAllPaged(filter).map {
            runBlocking(IO) {
                it.diveData =
                    singleDiveDataRepo.getSingleDiveDataById(it.logbookDiveEntity.diveId!!)
            }
            return@map it
        }
    }

    suspend fun upsertLogbookDive(logbookDive: LogbookDive) {
        val diveId = singleDiveDataRepo.upsert(logbookDive.diveData!!)
        logbookDive.logbookDiveEntity.diveId = diveId
        if (logbookDive.logbookDiveEntity.logbookDiveId == null) {
            logbookDiveDao.insert(logbookDive.logbookDiveEntity)
        } else {
            logbookDiveDao.update(logbookDive.logbookDiveEntity)
        }
    }

}