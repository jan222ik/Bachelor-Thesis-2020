package com.github.jan222ik.divelogbook.ui.fragments.edit

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.ui.viewmodel.EditViewModel
import kotlinx.android.synthetic.main.fragment_edit_options_existing.view.*


class EditOptionsExistingFragment : Fragment() {


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_edit_options_existing, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val navController = Navigation.findNavController(view)

        view.backBtn.setOnClickListener {
            activity!!.onBackPressed()
        }

        view.editExistingBtn.setOnClickListener {
            ViewModelProviders.of(requireActivity()).get(EditViewModel::class.java).forceModuleView()
            navController.navigate(EditOptionsExistingFragmentDirections.actionEditOptionsExistingFragmentToEditModulesFragment())
        }

        view.deleteExistingBtn.setOnClickListener {
            Toast.makeText(activity!!, "Delete is not implemented yet", Toast.LENGTH_SHORT).show()
        }
    }

}