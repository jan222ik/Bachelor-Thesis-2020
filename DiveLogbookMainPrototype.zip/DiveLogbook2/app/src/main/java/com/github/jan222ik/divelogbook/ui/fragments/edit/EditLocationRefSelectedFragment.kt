package com.github.jan222ik.divelogbook.ui.fragments.edit

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.ui.fragments.read.appliers.AddressApplier
import com.github.jan222ik.divelogbook.ui.fragments.read.appliers.DiveLocationApplier
import com.github.jan222ik.divelogbook.ui.viewmodel.EditViewModel
import kotlinx.android.synthetic.main.fragment_edit_common_nav.view.*
import kotlinx.android.synthetic.main.fragment_edit_location_ref_selected.view.*
import com.github.jan222ik.divelogbook.ui.fragments.edit.EditLocationRefSelectedFragmentDirections as ThisDirections


class EditLocationRefSelectedFragment : Fragment() {

    lateinit var editViewModel: EditViewModel
    lateinit var navController: NavController

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_edit_location_ref_selected, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        editViewModel = ViewModelProviders.of(activity!!).get(EditViewModel::class.java)

        editViewModel.locationRefEdit.location.observe(activity!!, Observer {
            if (it == null) {
                navController.navigate(ThisDirections.actionEditLocationRefSelectedFragmentToEditLocationRefSearchFragment())
            } else {
                DiveLocationApplier.apply(view, it)
                AddressApplier.apply(view, it.address)
            }
        })

        view.changeLocationBtn.setOnClickListener {
            navController.navigate(ThisDirections.actionEditLocationRefSelectedFragmentToEditLocationRefSearchFragment())
        }

        view.nextBtn.setOnClickListener {
            editViewModel.setNextChainFragment()
            navController.navigate(ThisDirections.actionEditLocationRefSelectedFragmentToEditModulesFragment())
        }
    }

}