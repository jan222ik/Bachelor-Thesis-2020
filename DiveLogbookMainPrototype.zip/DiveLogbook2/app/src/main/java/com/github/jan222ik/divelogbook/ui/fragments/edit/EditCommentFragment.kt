package com.github.jan222ik.divelogbook.ui.fragments.edit

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.activity.addCallback
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.Edit
import com.github.jan222ik.divelogbook.ui.viewmodel.EditViewModel
import com.github.jan222ik.divelogbook.ui.viewmodel.LogbookViewModel
import kotlinx.android.synthetic.main.fragment_edit_comment.view.*
import kotlinx.coroutines.runBlocking

class EditCommentFragment : Fragment() {

    lateinit var editViewModel: EditViewModel
    lateinit var diveViewModel: LogbookViewModel
    lateinit var navController: NavController

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner) {
            editViewModel.setPreviousChainFragment {
                navController.popBackStack()
            }
            navController.navigateUp()
        }
        return inflater.inflate(R.layout.fragment_edit_comment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        editViewModel = ViewModelProviders.of(requireActivity()).get(EditViewModel::class.java)
        diveViewModel = ViewModelProviders.of(requireActivity()).get(LogbookViewModel::class.java)
        with(view.finishEditBtn) {
            setOnClickListener {
                runBlocking {
                    editViewModel.commentEdit.comment.setValue(Edit.ByUser(view.commentEditText.textString))
                    editViewModel.setNextChainFragment()
                    navController.navigate(EditCommentFragmentDirections.actionEditCommentFragmentToEditModulesFragment())
                }
            }
        }
        with(view.commentEditText) {
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable) {}
                override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                    with(editViewModel.commentEdit) {
                        comment.setValue(Edit.ByUser(view.commentEditText.textString), view.commentEditText)
                    }
                }
            })
            with(editViewModel.commentEdit) {
                textString = comment.getValue().value ?: ""
            }
        }
    }

    private var EditText.textString
        get() = this.text.toString()
        set(value) = this.setText(value)

}