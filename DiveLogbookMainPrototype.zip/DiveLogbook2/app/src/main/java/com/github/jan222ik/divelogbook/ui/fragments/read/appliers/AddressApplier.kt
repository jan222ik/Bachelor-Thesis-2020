package com.github.jan222ik.divelogbook.ui.fragments.read.appliers

import android.view.View
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.database.entities.AddressEntity
import kotlinx.android.synthetic.main.detail_address.view.*

object AddressApplier {
    fun apply(view: View, address: AddressEntity?) {
        with(view) {
            val missing = lazy { resources.getString(R.string.missingData) }
            addressCountry.text = address?.country ?: missing.value
            addressZip.text = address?.zip ?: missing.value
            addressCity.text = address?.city ?: missing.value
            addressStreet.text = address?.street ?: missing.value
            addressHouse.text = address?.houseNumber ?: missing.value
        }
    }
}