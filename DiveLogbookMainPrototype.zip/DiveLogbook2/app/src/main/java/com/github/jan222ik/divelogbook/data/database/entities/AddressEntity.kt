package com.github.jan222ik.divelogbook.data.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class AddressEntity(
    var country: String,
    var zip: String? = null,
    var city: String? = null,
    var street: String? = null,
    var houseNumber: String? = null
) {
    @PrimaryKey(autoGenerate = true)
    var addressId: Long? = null
}