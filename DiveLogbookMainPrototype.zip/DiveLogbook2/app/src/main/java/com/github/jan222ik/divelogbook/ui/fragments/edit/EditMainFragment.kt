package com.github.jan222ik.divelogbook.ui.fragments.edit

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.ui.viewmodel.EditViewModel
import kotlinx.android.synthetic.main.fragment_edit_main.view.*

class EditMainFragment : Fragment() {

    lateinit var navController: NavController

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_edit_main, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        with(view.startBtn) {
            setOnClickListener {
                navController.navigate(EditMainFragmentDirections.actionEditMainFragmentToEditModulesFragment())
            }
        }
        val editViewModel = ViewModelProviders.of(requireActivity()).get(EditViewModel::class.java)
        with(view.cameraBtn) {
            setOnClickListener {
                editViewModel.initChainFragmentNav(editViewModel.moduleListConfigName.value.toString())
                navController.navigate(EditMainFragmentDirections.actionEditMainFragmentToPermissionsFragment())
            }
        }
        with(view.exploreBtn) {
            setOnClickListener {
                editViewModel.forceModuleView()
                navController.navigate(EditMainFragmentDirections.actionEditMainFragmentToEditModulesFragment())
            }
        }
    }

}