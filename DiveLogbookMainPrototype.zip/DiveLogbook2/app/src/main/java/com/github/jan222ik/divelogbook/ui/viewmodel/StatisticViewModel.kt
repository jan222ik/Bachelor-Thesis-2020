package com.github.jan222ik.divelogbook.ui.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.github.jan222ik.divelogbook.data.database.db.DiveEntityDatabase

class StatisticViewModel(application: Application) : AndroidViewModel(application) {

    private val db = DiveEntityDatabase.getDatabase(application, viewModelScope)
    /*
    private val singleDiveDataRepo = SingleDiveDataRepo(
        db.diveEntityDao(),
        db.diveDepthDao(),
        db.diveTemporalDao(),
        db.diveSpotDao(),
        db.diveLocationDao(),
        db.addressDao()
    )
    private val logbookDiveRepo = LogbookDiveRepo(db.logbookDiveDao(), singleDiveDataRepo)
     */

    fun cumulativeBaseTime(): LiveData<Long> {
        return db.diveTemporalDao().getCumulativeBaseTime()
    }

}