package com.github.jan222ik.divelogbook.ui.fragments.edit.camera.experiment.experiments.filters


import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc


object Filter {
    fun greyscale(src: Mat): Mat {
        val tmp = Mat()
        Imgproc.cvtColor(src, tmp, Imgproc.COLOR_BGR2GRAY)
        val dst = Mat()
        Imgproc.cvtColor(tmp, dst, Imgproc.COLOR_GRAY2BGR)
        return dst
    }

    fun threshold(src: Mat): Mat {
        val dst = Mat()
        Imgproc.threshold(src, dst, 3.0, 255.0, 0)
        return dst
    }

    fun adaptiveGaussianThreshold(src: Mat): Mat {
        val dst = Mat()
        val tmp = Mat()
        val tmp2 = Mat()
        Imgproc.cvtColor(src, tmp, Imgproc.COLOR_BGR2GRAY)
        Imgproc.adaptiveThreshold(tmp, tmp2, 255.0, Imgproc.ADAPTIVE_THRESH_MEAN_C, Imgproc.THRESH_BINARY_INV, 11, 2.0)
        Imgproc.cvtColor(tmp2, dst, Imgproc.COLOR_GRAY2BGR)
        return dst
    }

    fun otsuThreshold(src: Mat): Mat {
        val dst = Mat()
        val tmp = Mat()
        val tmp2 = Mat()
        Imgproc.cvtColor(src, tmp, Imgproc.COLOR_BGR2GRAY)
        Imgproc.threshold(tmp, tmp2, 240.0, 255.0, Imgproc.THRESH_OTSU or Imgproc.THRESH_BINARY)
        Imgproc.cvtColor(tmp2, dst, Imgproc.COLOR_GRAY2BGR)
        return dst
    }

    fun sobel(src: Mat): Mat {
        val dst = Mat()
        Imgproc.Sobel(src, dst, CvType.CV_8U, 1, 0, 1, 0.5, 0.0, Core.BORDER_DEFAULT)
        return dst
    }

    fun erode(src: Mat): Mat {
        val dst = Mat()
        val erosion_size = 5.0
        val element = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(erosion_size, erosion_size))
        Imgproc.erode(src, dst, element)
        return dst
    }
}