package com.github.jan222ik.divelogbook.data.database.daos

import androidx.room.*
import com.github.jan222ik.divelogbook.data.database.entities.AddressEntity
import com.github.jan222ik.divelogbook.data.database.entities.DiveGasMixtureEntity

@Dao
interface DiveGasMixtureDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(diveGasMixtureEntity: DiveGasMixtureEntity): Long

    @Update
    suspend fun update(diveGasMixtureEntity: DiveGasMixtureEntity)

    @Query("DELETE FROM DiveGasMixtureEntity")
    suspend fun deleteAll()

    @Query("Select * FROM DiveGasMixtureEntity Where gaxMixtureId = :gasMixtureId")
    suspend fun getById(gasMixtureId: Long): DiveGasMixtureEntity
}