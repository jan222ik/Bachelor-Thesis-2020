package com.github.jan222ik.divelogbook.data.database.daos

import androidx.room.*
import com.github.jan222ik.divelogbook.data.database.entities.DiveSpotEntity


@Dao
interface DiveSpotDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(diveSpotEntity: DiveSpotEntity): Long

    @Update
    suspend fun update(diveSpotEntity: DiveSpotEntity)

    @Query("DELETE FROM DiveSpotEntity")
    suspend fun deleteAll()

    @Query("Select * FROM DiveSpotEntity Where spotId = :spotId")
    suspend fun getById(spotId: Long): DiveSpotEntity

}