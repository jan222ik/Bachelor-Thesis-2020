package com.github.jan222ik.divelogbook.ui.fragments.edit

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.addCallback
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.ui.viewmodel.EditViewModel
import com.github.jan222ik.divelogbook.ui.viewmodel.SliderTextBindViewWrapper
import kotlinx.android.synthetic.main.fragment_edit_gas_mixture.view.*


class EditGasMixtureFragment : Fragment() {

    private lateinit var navController: NavController
    private lateinit var editViewModel: EditViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_edit_gas_mixture, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        editViewModel = ViewModelProviders.of(activity!!).get(EditViewModel::class.java)
        navController = Navigation.findNavController(view)

        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner) {
            editViewModel.setPreviousChainFragment {
                navController.popBackStack()
            }
            navController.navigateUp()
        }

        val tankSizeWrapper = SliderTextBindViewWrapper(view.tankSizeSlider, view.editTankSize, 12F) {
            println("TankSizeUpdate value = $it")
        }

    }

}