package com.github.jan222ik.divelogbook.data.database.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "dive")
data class DiveEntity(
    //var isFreeDive: Boolean,
    @ColumnInfo(name = "temporalFK")
    var temporalId: Long,
    @ColumnInfo(name = "depthFK")
    var depthId: Long,
    @ColumnInfo(name = "locationFK")
    var locationId: Long? = null,
    @ColumnInfo(name = "gasMixtureFK")
    var gasMixtureId: Long? = null,
    @ColumnInfo(name = "ratingFK")
    var ratingId: Long? = null,
    //var divebaseId: Int? = null,
    //var buddies: List<Diver>? = listOf(),
    //var guides:  List<Diver>? = listOf(),
    @ColumnInfo(name = "commentFK")
    var commentId: Long? = null
){
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "diveId")
    var diveId: Long? = null
}