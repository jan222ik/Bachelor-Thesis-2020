package com.github.jan222ik.divelogbook.ui.fragments.edit.camera.experiment.experiments

import android.content.Context
import android.graphics.Bitmap
import com.github.jan222ik.divelogbook.ui.fragments.edit.camera.experiment.experiments.filters.Filter
import org.opencv.android.Utils
import org.opencv.core.Mat

class ThresholdOtsuExperiment(context: Context) : ExperimentBase(context) {

    override suspend fun process(image: Bitmap, experimentData: ExperimentData): ExperimentData {
        val startMillis = System.currentTimeMillis()
        val mat = Mat()
        Utils.bitmapToMat(image, mat)

        val threshMat = Filter.otsuThreshold(mat)

        experimentData.timeMillisPreprocessing = System.currentTimeMillis().minus(startMillis)
        saveAsImage(convertMatToBitMap(threshMat)!!, "thresh_otsu")
        return asyncAnalyseImage(convertMatToBitMap(threshMat)!!, experimentData)
    }


}