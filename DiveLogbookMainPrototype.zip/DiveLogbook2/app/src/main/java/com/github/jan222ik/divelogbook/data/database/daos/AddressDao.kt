package com.github.jan222ik.divelogbook.data.database.daos

import androidx.room.*
import com.github.jan222ik.divelogbook.data.database.entities.AddressEntity

@Dao
interface AddressDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(addressEntity: AddressEntity): Long

    @Update
    suspend fun update(addressEntity: AddressEntity)

    @Query("DELETE FROM AddressEntity")
    suspend fun deleteAll()

    @Query("Select * FROM AddressEntity Where addressId = :addressId")
    suspend fun getById(addressId: Long): AddressEntity
}