package com.github.jan222ik.divelogbook.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.lifecycle.liveData
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.ui.fragments.read.appliers.AddressApplier
import com.github.jan222ik.divelogbook.ui.fragments.read.appliers.DiveLocationApplier
import com.github.jan222ik.divelogbook.ui.viewmodel.LogbookViewModel

class LocationDetailFragment : Fragment() {

    private lateinit var navController: NavController
    private lateinit var viewModel: LogbookViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_location_detail, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        viewModel = ViewModelProviders.of(activity!!).get(LogbookViewModel::class.java)
        val liveData = liveData {
            val detailLocation = viewModel.getDetailLocation()
            emit(detailLocation)
        }
        liveData.observe(viewLifecycleOwner, Observer {
            DiveLocationApplier.apply(view, it!!)
            AddressApplier.apply(view, it.address)
        })
    }

}