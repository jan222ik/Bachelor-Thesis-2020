package com.github.jan222ik.divelogbook.data.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class DiveCommentEntity(
    var comment: String
) {
    @PrimaryKey(autoGenerate = true)
    var commentId: Long? = null
}