package com.github.jan222ik.divelogbook.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.*
import androidx.paging.LivePagedListBuilder
import androidx.paging.PagedList
import com.blongho.country_data.World
import com.github.jan222ik.divelogbook.data.database.db.DiveEntityDatabase
import com.github.jan222ik.divelogbook.data.database.pojos.DiveLocation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking

class LocationViewModel(application: Application) : AndroidViewModel(application) {

    init {
        World.init(application)
    }

    private val db = DiveEntityDatabase.getDatabase(application, viewModelScope)

    var allLocationsPaged: LiveData<PagedList<DiveLocation>>? = null
    var allLocations: LiveData<List<DiveLocation>>? = null
    var allLocationsFilter = MutableLiveData<LocationFilter>()
    var allLocationsLatestFilter: LocationFilter? = null

    fun initLocation() {
        Log.d("VM", "init PagedSource")
        val config = PagedList.Config.Builder().setPageSize(20).build()
        allLocationsPaged = Transformations.switchMap<LocationFilter, PagedList<DiveLocation>>(allLocationsFilter)
        { input: LocationFilter? ->
            Log.d("VM", "Transformation PagedSource")
            if (input == null) {
                return@switchMap LivePagedListBuilder(db.diveLocationDao().getAllPaged(), config).build()
            } else {
                return@switchMap LivePagedListBuilder(db.diveLocationDao().getPagedByFilter(input), config).build()
            }
        }
        allLocations = db.diveLocationDao().getAll()
    }

    fun applyLocationFilter() {
        allLocationsFilter.postValue(allLocationsLatestFilter)
    }

    fun setEdit(nothing: Nothing?) {
        TODO("setEdit not implemented")
    }

    fun getAllUsedCountries(): List<String> {
        return runBlocking(Dispatchers.IO) {
            db.diveLocationDao().getAllUsedCountries()
        }
    }

    fun updateFilter(filter: LocationFilter) {
        allLocationsLatestFilter = filter
        applyLocationFilter()
    }

    data class LocationFilter(
        val mixedString: String
    )
}