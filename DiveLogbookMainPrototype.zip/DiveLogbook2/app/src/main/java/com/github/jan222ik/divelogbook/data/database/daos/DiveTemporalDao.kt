package com.github.jan222ik.divelogbook.data.database.daos

import androidx.lifecycle.LiveData
import androidx.room.*
import com.github.jan222ik.divelogbook.data.database.entities.DiveTemporalEntity

@Dao
interface DiveTemporalDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(diveTemporalEntity: DiveTemporalEntity): Long

    @Update
    suspend fun update(diveTemporalEntity: DiveTemporalEntity)

    @Query("DELETE FROM DiveTemporalEntity")
    suspend fun deleteAll()

    @Query("Select * FROM DiveTemporalEntity Where diveTemporalId = :diveTemporalId")
    suspend fun getById(diveTemporalId: Long): DiveTemporalEntity

    @Query("Select SUM(durationSec) From DiveTemporalEntity" )
    fun getCumulativeBaseTime(): LiveData<Long>
}