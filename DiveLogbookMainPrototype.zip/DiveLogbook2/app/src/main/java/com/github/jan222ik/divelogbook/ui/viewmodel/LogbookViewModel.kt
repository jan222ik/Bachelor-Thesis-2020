package com.github.jan222ik.divelogbook.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.*
import androidx.paging.LivePagedListBuilder
import androidx.paging.PagedList
import com.github.jan222ik.divelogbook.data.database.CSVDiveImport
import com.github.jan222ik.divelogbook.data.database.db.DiveEntityDatabase
import com.github.jan222ik.divelogbook.data.database.pojos.DiveLocation
import com.github.jan222ik.divelogbook.data.database.pojos.LogbookDive
import com.github.jan222ik.divelogbook.data.repo.LogbookDiveRepo
import com.github.jan222ik.divelogbook.data.repo.SingleDiveDataRepo
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import java.io.File
import java.io.InputStream


class LogbookViewModel(application: Application) : AndroidViewModel(application) {

    var allDives: LiveData<PagedList<LogbookDive>>? = null
    var allDivesFilter = MutableLiveData<Filter?>()
    var latestFilter: Filter? = null

    private val db = DiveEntityDatabase.getDatabase(application, viewModelScope)
    private val singleDiveDataRepo = SingleDiveDataRepo(
        db.diveEntityDao(),
        db.diveDepthDao(),
        db.diveTemporalDao(),
        db.diveSpotDao(),
        db.diveLocationDao(),
        db.diveCommentDao(),
        db.diveGasMixtureDao(),
        db.addressDao()
    )
    private val logbookDiveRepo = LogbookDiveRepo(db.logbookDiveDao(), singleDiveDataRepo)

    fun initDives() {
        Log.d("VM", "init PagedSource")
        val config = PagedList.Config.Builder().setPageSize(20).build()
        allDives = Transformations.switchMap<Filter, PagedList<LogbookDive>>(allDivesFilter)
        { filter: Filter? ->
            Log.d("VM", "Transformation PagedSource with Filter: $filter")
            return@switchMap LivePagedListBuilder(logbookDiveRepo.getAllPaged(filter), config).build()
        }
    }

    fun invalidateDives() {
        allDives!!.value!!.dataSource.invalidate()
    }

    fun applyLatestFilter() {
        allDivesFilter.postValue(latestFilter)
    }

    fun updateFilter(filter: Filter) {
        latestFilter = filter
        applyLatestFilter()
    }

    var allLocations: LiveData<PagedList<DiveLocation>>? = null
    var allLocationsFilter = MutableLiveData<Filter>()

    var allLocationsLatestFilter: Filter? = null

    fun initLocation() {
        Log.d("VM", "init PagedSource")
        val config = PagedList.Config.Builder().setPageSize(20).build()
        allLocations = Transformations.switchMap<Filter, PagedList<DiveLocation>>(allLocationsFilter)
        { input: Filter? ->
            Log.d("VM", "Transformation PagedSource")
            return@switchMap LivePagedListBuilder(db.diveLocationDao().getAllPaged(), config).build()
        }
    }

    fun invalidateLocations() {
        allLocations?.value?.dataSource?.invalidate()
    }


    fun applyLocationFilter() {
        allLocationsFilter.postValue(allLocationsLatestFilter)
    }

    private var detailID: Long? = null

    private var detail: LogbookDive? = null

    fun setDetail(value: LogbookDive?) {
        detailID = value?.logbookDiveEntity?.diveId
    }

    suspend fun getDetail(): LogbookDive? {
        detail = if (detailID != null) {
            val async = viewModelScope.async(IO) { logbookDiveRepo.getLogbookDiveById(detailID!!) }
            async.await()
        } else {
            null
        }
        return detail
    }

    fun editDetails() {
        editID = detailID
    }

    private var editID: Long? = null

    private var edit: LogbookDive? = null

    fun setEdit(value: LogbookDive?) {
        editID = value?.logbookDiveEntity?.diveId
    }

    suspend fun getEdit(): LogbookDive? {
        edit = if (editID != null) {
            val async = viewModelScope.async(IO) { logbookDiveRepo.getLogbookDiveById(editID!!) }
            async.await()
        } else null
        return edit
    }

    suspend fun updateEditEntry() {
        val async = viewModelScope.async(IO) {
            if (edit != null) {
                logbookDiveRepo.upsertLogbookDive(edit!!)
            }
        }
        async.await()
    }

    private var locationDetailID: Long? = null

    private var locationDetail: DiveLocation? = null

    fun setDetailLocation(value: DiveLocation?) {
        locationDetailID = value?.entity?.locationId
    }

    suspend fun getDetailLocation(): DiveLocation? {
        locationDetail = if (locationDetailID != null) {
            val async = viewModelScope.async(IO) { db.diveLocationDao().getPojoById(locationDetailID!!) }
            async.await()
        } else {
            null
        }
        return locationDetail
    }

    fun getAllUsedCountries(): List<String> {
        return runBlocking(IO) {
            db.diveLocationDao().getAllUsedCountries()
        }
    }

    fun importCSV(dives: InputStream, location: InputStream, onFinish: () -> Unit) {
        val csvDiveImport = CSVDiveImport(database = db)
        runBlocking(IO) {
            csvDiveImport.readAll(dives, location)
            onFinish()
        }
    }
}