package com.github.jan222ik.divelogbook.ui.fragments.edit

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.activity.addCallback
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.github.jan222ik.divelogbook.R
import com.github.jan222ik.divelogbook.data.updateAsUser
import com.github.jan222ik.divelogbook.ui.viewmodel.EditViewModel
import kotlinx.android.synthetic.main.fragment_edit_common_nav.view.*
import kotlinx.android.synthetic.main.fragment_edit_logbook_dive.view.*

class EditLogbookDiveFragment : Fragment() {

    lateinit var editViewModel: EditViewModel
    lateinit var navController: NavController

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner) {
            editViewModel.setPreviousChainFragment {
                navController.popBackStack()
            }
            navController.navigateUp()
        }
        return inflater.inflate(R.layout.fragment_edit_logbook_dive, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        editViewModel = ViewModelProviders.of(activity!!).get(EditViewModel::class.java)
        view.nextBtn.setOnClickListener {
            with(editViewModel.logbookEdit) {
                number = number.updateAsUser(view.editLogbookNumber.textString.safeDouble()?.toInt())
            }
            editViewModel.setNextChainFragment()
            navController.navigate(EditLogbookDiveFragmentDirections.actionEditLogbookDiveFragmentToEditModulesFragment())
        }
        val depth = editViewModel.logbookEdit
        with(view) {
            editLogbookNumber.textString = depth.number.value.toBlankStringOnNull()
            MaterialTextHelper.apply(depth.number, null, logbookNumberLayout, resources)
        }
    }

    private var EditText.textString
        get() = this.text.toString()
        set(value) = this.setText(value)

}

private fun Any?.toBlankStringOnNull(): String = this?.toString() ?: ""
