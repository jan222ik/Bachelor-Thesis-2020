package com.github.jan222ik.divelogbook.data.database.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class DiveDepthEntity (
    @ColumnInfo(name = "maxMetric")
    var maxMetric: Int? = null,
    @ColumnInfo(name = "avgMetric")
    var avgMetric: Int? = null
) {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "depthId")
    var depthId: Long? = null
}